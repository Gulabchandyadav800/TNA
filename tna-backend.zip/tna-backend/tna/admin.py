from django.contrib import admin
from simple_history.admin import SimpleHistoryAdmin
from .models import *
from django.contrib.auth.models import Group, Permission
# Register your models here.


admin.site.register(Role)
admin.site.register(User)
admin.site.register(EmployeeDetail, SimpleHistoryAdmin)
admin.site.register(Extension, SimpleHistoryAdmin)
admin.site.register(FabricDetail,SimpleHistoryAdmin)
admin.site.register(Notification,SimpleHistoryAdmin)
admin.site.register(UserNotification, SimpleHistoryAdmin)
admin.site.register(NotificationHistory, SimpleHistoryAdmin)
admin.site.register(NotificationMedium, SimpleHistoryAdmin)
admin.site.register(Form68Model, SimpleHistoryAdmin)
admin.site.register(StyleDetails,SimpleHistoryAdmin)
admin.site.register(TaskDetails, SimpleHistoryAdmin)
admin.site.register(Permission)
admin.site.register(Relationship, SimpleHistoryAdmin)
admin.site.register(TypeOfWork, SimpleHistoryAdmin)
admin.site.register(UserPermission)

