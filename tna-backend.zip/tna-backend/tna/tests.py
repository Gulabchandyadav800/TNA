import subprocess


def export_database(db_path, output_path):
    try:
        # Specify the full path to sqlite3 executable C:\sqlite3
        SQLITE_PATH = r"C:\sqlite3\sqlite3.exe"  # Adjust this path if needed
        print('SQLITE_PATH',SQLITE_PATH)

        # Run sqlite3 dump command and capture output
        result = subprocess.run(
            [SQLITE_PATH, db_path, '.dump'],
            capture_output=True, text=True, check=True
        )

        # Write the output to the specified file
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(result.stdout)

        print("Database export successful.")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error exporting database: {e}")
        return False


# Example usage
db_path = r"D:\Projects\Development Projects\Operation Boost\TNA\Backend\db.sqlite4"
output_path = r"D:\Projects\Development Projects\Operation Boost\TNA\Backend\database_dump.sql"

export_database(db_path, output_path)
