from rest_framework.permissions import BasePermission

class IsInGroup(BasePermission):

    def has_permission(self, request, view):
        required_groups = getattr(view, 'required_groups', None)
        if required_groups:
            return request.user.is_authenticated and request.user.groups.filter(name__in=required_groups).exists()
        return True