# serializers.py
from rest_framework import serializers
from django.core.exceptions import ValidationError
from django.contrib.auth.hashers import check_password
from rest_framework.exceptions import ValidationError
from .models import *
from django.contrib.auth.models import Permission
from django.utils.timezone import now
from django.contrib.auth.password_validation import validate_password
from django.contrib.contenttypes.models import ContentType
from django.db.models import Sum



# Serializer for adding new users
class UserSerializer(serializers.ModelSerializer):
    user_type = serializers.SerializerMethodField() # Get user type (role)

    class Meta:
        model = User
        fields = [
            "id",
            "email",
            "name",
            "user_type",
        ]

    # Validate email uniqueness before saving user
    def validate(self, data):
        if User.objects.filter(email=data.get("email")).exists():
            raise ValidationError("Email is already in use.")
        return data
    
    # Return the role name of the user
    def get_user_type(self, obj):
        return obj.role.role_name if obj.role else None
    
    # Create a new user and save
    def create(self, validated_data):
        user = User(**validated_data)
        user.save()
        return user


# Serializer for user login
class LoginSerializer(serializers.Serializer):
    email = serializers.CharField(required=True)
    password = serializers.CharField(write_only=True, required=True)
    
    # Validate login credentials (email and password)
    def validate(self, attrs):
        email = attrs.get("email")
        password = attrs.get("password")
        try:
            email = User.objects.get(email=email)
        except:
            raise ValidationError("Invalid email or password")
        if not check_password(password, email.password):
            raise ValidationError("Invalid email or password")
        attrs["email"] = email
        return attrs


# Serializer for changing user password
class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True, write_only=True)
    new_password = serializers.CharField(required=True, write_only=True, validators=[validate_password])
    confirm_password = serializers.CharField(required=True, write_only=True)
    

    # Validate that new password and confirm password match
    def validate(self, attrs):
        if attrs["new_password"] != attrs["confirm_new_password"]:
            raise serializers.ValidationError({"confirm_new_password": "New passwords must match."})
        return attrs

# Serializer for resetting user password
class PasswordResetSerializer(serializers.Serializer):
    user_id = serializers.IntegerField()


# Serializer for roles (assigning roles to users)
class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = [
            "id",
            "role_name",
        ]


# Serializer for employee details
class EmployeeDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeDetail
        fields = ["manager", "user"]


# Serializer for fabric details associated with an order
class FabricDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = FabricDetail
        fields = ["style_details", "fabric_name"]
    
    # Validate fabric name to ensure it's unique per order
    def validate_fabric_name(self, value):
        if FabricDetail.objects.filter(
            order=self.instance.order, fabric_name=value
        ).exists():
            raise serializers.ValidationError(
                "This fabric name already exists for the order."
            )
        return value


# Serializer for listing user details with their role 
class UsersSerializer(serializers.ModelSerializer):
    role = RoleSerializer()

    class Meta:
        model = User
        fields = ["id", "name", "email", "role", "department", "designation"]


# Serializer for approving extensions
class ApproveExtensionSerializer(serializers.ModelSerializer):
   
    class Meta:
        model = Extension
        fields = ["id","approved_status"]  


# Serializer for notification history details
class NotificationHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationHistory
        fields = ["id", "status","user_notification"]


# Serializer for notification medium delivery details
class NotificationMediumSerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationMedium
        fields = ["id", "delivery_method", "user_notification_id","notification_delivered_at"]


# Serializer for user notifications
class UserNotificationSerializer(serializers.ModelSerializer):

    class Meta:
        model = UserNotification
        fields = ["id", "user", "notification"]

# Serializer for notifications with additional sender details
class NotificationSerializer(serializers.ModelSerializer):
    sender_name = serializers.SerializerMethodField()

    class Meta:
        model = Notification
        fields = ["id", "message", "is_read", "sender", "sender_name","Notification_type", "notification_type_id", "created_at"]

    # Get the sender's name from the sender object 
    def get_sender_name(self, obj):
        return obj.sender.name if obj.sender else None


# Serializer for Form 68, related to extensions
class Form68Serializers(serializers.ModelSerializer):
    extension_name = serializers.SerializerMethodField()
    task_name = serializers.SerializerMethodField()
    task_id = serializers.SerializerMethodField()
    tna_name = serializers.SerializerMethodField()
    tna_id = serializers.SerializerMethodField()
    extension_days = serializers.SerializerMethodField()

    class Meta:
        model = Form68Model
        fields = ["form_id", "amount", "extension","extension_name","task_name", "reason","task_id","tna_name","tna_id","extension_days","created_at"]

    # Get the extension name from the related extension object
    def get_extension_name(self, obj):
        return obj.extension.sub_task.name if obj.extension else None
    def get_task_name(self, obj):
        return obj.extension.sub_task.name if obj.extension.sub_task else None
    def get_task_id(self, obj):
        return obj.extension.sub_task.id if obj.extension.sub_task else None
    def get_tna_name(self, obj):
        return obj.extension.sub_task.style.style_name if  obj.extension.sub_task.style else None
    def get_tna_id(self, obj):
        return obj.extension.sub_task.style.id if obj.extension.sub_task.style else None 
    def get_extension_days(self, obj):
        return obj.extension.extension_days if obj.extension else None  

# Serializer for extensions
class ExtensionSerializer(serializers.ModelSerializer):
    style_id = serializers.SerializerMethodField()
    style_name = serializers.SerializerMethodField()
    sum_of_extension_unapprove = serializers.SerializerMethodField()
    sum_of_extension_approve = serializers.SerializerMethodField()
    subtask_name = serializers.SerializerMethodField()
    
    class Meta:
        model = Extension  
        fields = [
            "id",
            "style_id",
            "style_name",
            'extension_days',
            'sub_task',
            "subtask_name",
            "created_at",
            "extension_days",
            "approved_status",
            "sum_of_extension_unapprove",
            "sum_of_extension_approve",
        ]
     
   # Get the style ID from the related sub_task object
    def get_style_id(self, obj):
        return obj.sub_task.style.id if obj.sub_task and obj.sub_task.style else None

    # Get the style name from the related sub_task object
    def get_style_name(self, obj):
        return obj.sub_task.style.style_name if obj.sub_task and obj.sub_task.style else None
    
    # Sum of unapproved extensions for the entire style
    def get_sum_of_extension_unapprove(self, obj):
        return (
            Extension.objects.filter(
                sub_task__style=obj.sub_task.style, approved_status=False
            ).aggregate(total_unapproved=Sum("extension_days"))["total_unapproved"]
            or 0
        )
    # Sum of approved extensions for the entire style
    def get_sum_of_extension_approve(self, obj):
        return (
            Extension.objects.filter(
                sub_task__style=obj.sub_task.style, approved_status=True
            ).aggregate(total_approved=Sum("extension_days"))["total_approved"]
            or 0
        )
    
    # Validate extension days to ensure they are positive
    def validate_extension_days(self, value):
        if value <= 0:
            raise serializers.ValidationError(
                "Extension days must be a positive integer."
            )
        return value
    
    def get_subtask_name(self, obj):
        return obj.sub_task.name if obj.sub_task else None

# Serializer for task details
class TaskDetailsSerializer(serializers.ModelSerializer):
    index = serializers.SerializerMethodField()

    class Meta:
        model = TaskDetails
        fields = [
            "id",
            "index",
            "description",
            "requiredMaterial",
            "originalStartDate",
            "requiredDays",
            "originalEndDate",
            "endDate",
        ]
    
    # Return the index of the task
    def get_index(self, obj):
        return obj.id
    

# Serializer for relationships between tasks
class RelationshipSerializer(serializers.ModelSerializer):
    childIndex = serializers.SerializerMethodField()
    parentIndex = serializers.SerializerMethodField()
    childId = serializers.SerializerMethodField()
    parentId = serializers.SerializerMethodField()

    class Meta:
        model = Relationship
        fields = ["childId","parentId","childIndex", "parentIndex", "offset_days"]
    
    # Get child task index
    def get_childIndex(self, obj):
        return obj.child.index
    
    # Get child task ID
    def get_childId(self, obj):
        return obj.id
    
    # Get parent task index
    def get_parentIndex(self, obj):
        return obj.parent.index
    
    # Get parent task ID
    def get_parentId(self, obj):
        return obj.parent.id


# Serializer for style details (tasks and relationships
class StyleDetailsSerializer(serializers.ModelSerializer):
    rows = serializers.SerializerMethodField()
    relationships = serializers.SerializerMethodField()
    po_details = serializers.SerializerMethodField()
    tableHeader = serializers.SerializerMethodField()
    qa_name = serializers.SerializerMethodField()
    vendor_name = serializers.SerializerMethodField()
    creator_name = serializers.SerializerMethodField()
    qa_id = serializers.SerializerMethodField()
    vendor_id = serializers.SerializerMethodField()
    creator_id = serializers.SerializerMethodField()

    class Meta:
        model = StyleDetails
        fields = [
            "id",
            "style_name",
            "qa_name",
            "qa_id",
            "vendor_name",
            "vendor_id",
            "creator_name",
            "creator_id",
            "order_place_date",
            "ship_date",
            "quantity",
            "average_production_per_day",
            "stitching",
            "machine_required",
            "po_details",
            "tableHeader",
            "rows",
            "relationships",
        ]
    
    # Get task rows for style details
    def get_rows(self, obj):
        tasks = obj.task_style.all()
        rows_data = []

        for task in tasks:
            parent_relationships = task.task_parents.all()
            offset_days=''
            for rel in parent_relationships:
                offset_days+=str(rel.offset_days)

            row = {
                'id':task.id,
                'index': task.index,
                'description': task.name,
                'requiredMaterial': task.required_material,
                'originalStartDate': task.original_start_date,
                'typeOfWork': task.type_of_work,
                'offset_days':offset_days,
                'requiredDays': task.required_days,
                'originalEndDate': task.original_end_date,
                'endDate': task.end_date,
            }
            row.update(self.get_extensions_for_task(task))
            rows_data.append(row)
        return rows_data
    
    # Get extensions related to a task, including their flags
    def get_extensions_for_task(self, task):
        extensions = task.extension_task.all()
        extension_dict = {}

        for i, ext in enumerate(extensions):
            if ext.extension_days is not None:
                extension_dict[f"extention_{i + 1}"] = ext.extension_days
                extension_dict[f"flag_{i + 1}"] = ext.approved_status
        return extension_dict
    
    # Get PO details as a list
    def get_po_details(self, obj):
        if obj.po_details:
            return [po.strip() for po in obj.po_details.split(",")]
        return []
    
    # Get relationships between tasks
    def get_relationships(self, obj):
        print("test",obj)

        relationships = Relationship.objects.filter(
            parent__style=obj,
            child__style=obj
        )
        print("relationships",relationships)
        return RelationshipSerializer(relationships, many=True).data
    
    # Get table header for extensions
    def get_tableHeader(self, obj):
        all_extensions = {}
        for task in obj.task_style.all():
            extensions = task.extension_task.all()
            if extensions:
                all_extensions[task.id] = len(extensions)
        if not all_extensions:
            return []

        max_extension_task = max(all_extensions, key=all_extensions.get)
        max_extensions = all_extensions[max_extension_task]
        extension_fields = [f"extension_{i + 1}" for i in range(max_extensions)]
        return extension_fields
    
    # Get QA name
    def get_qa_name(self, obj):
        return obj.qa.name if obj.qa else None
    
    # Get QA ID
    def get_qa_id(self, obj):
        return obj.qa.id if obj.qa else None
    
    # Get vendor name
    def get_vendor_name(self, obj):
        return obj.vendor.name if obj.vendor else None
    
    # Get vendor ID
    def get_vendor_id(self, obj):
        return obj.vendor.id if obj.vendor else None
    
    # Get creator name
    def get_creator_name(self, obj):
        return obj.creator.name if obj.creator else None
    # Get creator ID
    def get_creator_id(self, obj):
        return obj.creator.id if obj.creator else None


# Serializer for listing style tasks (TNA list)
class StyleListSerializer(serializers.ModelSerializer):

    # Fields to represent style and task details
    style_id = serializers.IntegerField(source='style.id')
    task_id = serializers.IntegerField(source='id')
    style_name = serializers.CharField(source='style.style_name')
    qa_name = serializers.CharField(source='style.qa.name')
    qa_id = serializers.CharField(source='style.qa.id')
    vendor_name = serializers.CharField(source='style.vendor.name')
    vendor_id = serializers.CharField(source='style.vendor.id')
    creator_name = serializers.CharField(source='style.creator.name')
    creator_id = serializers.CharField(source='style.creator.id')
    quantity = serializers.IntegerField(source='style.quantity')

    class Meta:
        model = TaskDetails
        fields = [
            'style_id',
            'task_id',
            'style_name',
            'qa_name',
            'qa_id',
            'vendor_name',
            'vendor_id',
            'creator_name',
            'creator_id',
            'quantity',
            'name',
            'original_start_date',
            'original_end_date',
            'end_date',
            'type_of_work',
        ]


# Serializer for QA Calendar, listing task and style information
class QACalendarSerializer(serializers.ModelSerializer):

    # Fields representing style and task details for QA Calendar
    style_id = serializers.IntegerField(source='style.id')
    task_id = serializers.IntegerField(source='id')
    style_name = serializers.CharField(source='style.style_name')
    qa_name = serializers.CharField(source='style.qa.name')
    vendor_name = serializers.CharField(source='style.vendor.name')
    creator_name = serializers.CharField(source='style.creator.name')
    quantity = serializers.IntegerField(source='style.quantity')

    class Meta:
        model = TaskDetails
        fields = [
            'style_id',
            'task_id',
            'style_name',
            'qa_name',
            'vendor_name',
            'creator_name',
            'quantity',
            'name',
            'original_start_date',
            'original_end_date',
            'end_date',
            'type_of_work',
            'required_material',
            'required_days'
        ]


# Serializer for user permissions with role information    
class UserPermissionSerializer(serializers.ModelSerializer):
    role = serializers.PrimaryKeyRelatedField(queryset=Role.objects.all())
    permission_names = serializers.SerializerMethodField()
    role_name = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = UserPermission
        fields = ["id", "role", "role_name", "permission", "permission_names", "view_name"]
    
    # Get the permission names for the current UserPermission
    def get_permission_names(self, obj):
        return [perm.name for perm in obj.permission.all()]
    
    # Get the role name for the current UserPermission
    def get_role_name(self, obj):
        return obj.role.role_name

    # Create a new UserPermission instance with assigned permissions
    def create(self, validated_data):
        permissions = []
        view_name = validated_data.get('view_name')
        selected_permissions = validated_data.pop('permission', [])

        if view_name:
            # Create a permission for the view if view_name is provided
            formatted_name = view_name.replace("_", " ")
            permission_codename = f"view_{view_name}"
            content_type = ContentType.objects.get_for_model(UserPermission)

            permission, _ = Permission.objects.get_or_create(
                codename=permission_codename,
                name=f"Can view {formatted_name}",
                content_type=content_type
            )
            permissions.append(permission)
        else:
            # Use selected permissions from dropdown if no view_name
            permissions = selected_permissions
        
        # Create UserPermission instance and assign permissions
        user_permission = super().create(validated_data)
        user_permission.permission.set(permissions)

        return user_permission
    
    # Update an existing UserPermission instance with updated permissions
    def update(self, instance, validated_data):
        permissions = []
        view_name = validated_data.get('view_name', instance.view_name)
        selected_permissions = validated_data.pop('permission', [])

        if view_name:
            # Update with view-specific permission if view_name is provided
            formatted_name = view_name.replace("_", " ")
            permission_codename = f"view_{view_name}"
            content_type = ContentType.objects.get_for_model(UserPermission)

            permission, _ = Permission.objects.get_or_create(
                codename=permission_codename,
                name=f"Can view {formatted_name}",
                content_type=content_type
            )
            
            permissions.append(permission)
        else:
            # Use selected permissions from dropdown if no view_name
            permissions = selected_permissions

        # Update the instance and assign the new permissions
        instance = super().update(instance, validated_data)
        instance.permission.set(permissions)

        return instance


class BaseHistorySerializer(serializers.ModelSerializer):
    """
    Base serializer for history tracking across all models.

    - Adds `changes` field for differences between historical records.
    - Adds `changed_by_name` field for the user who made the change.
    """
    changes = serializers.SerializerMethodField()
    changed_by_name = serializers.SerializerMethodField()

    def get_changes(self, obj):
        """
        Returns a list of field changes with old and new values.
        """
        if hasattr(obj, 'diff_against') and obj.prev_record:
            diff = obj.diff_against(obj.prev_record)
            return [{"field": change.field, "old": change.old, "new": change.new} for change in diff.changes]
        return []

    def get_changed_by_name(self, obj):
        """
        Returns full name of the user who made the historical change.
        """
        return obj.history_user.name if obj.history_user else None


class StyleDetailsHistorySerializer(BaseHistorySerializer):
    """
    Serializer for StyleDetails model history.
    Adds user-friendly names for related fields.
    """
    qa_name = serializers.CharField(source='qa.name', read_only=True)
    vendor_name = serializers.CharField(source='vendor.name', read_only=True)
    creator_name = serializers.CharField(source='creator.name', read_only=True)

    class Meta:
        model = StyleDetails.history.model
        fields = '__all__'


class TaskDetailsHistorySerializer(BaseHistorySerializer):
    """
    Serializer for TaskDetails model history.
    """
    style_name = serializers.CharField(source='style.style_name', read_only=True)

    class Meta:
        model = TaskDetails.history.model
        fields = '__all__'


class RelationshipHistorySerializer(BaseHistorySerializer):
    """
    Serializer for Relationship model history.
    """
    parent_task_name = serializers.CharField(source='parent.name', read_only=True)
    child_task_name = serializers.CharField(source='child.name', read_only=True)

    class Meta:
        model = Relationship.history.model
        fields = '__all__'


class ExtensionHistorySerializer(BaseHistorySerializer):
    """
    Serializer for Extension model history.
    """
    sub_task_name = serializers.CharField(source='sub_task.name', read_only=True)

    class Meta:
        model = Extension.history.model
        fields = '__all__'


class ExtExtensionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Extension
        fields = ["id","approved_status","extension_days","requested_by","approved_by"]


class ExtTaskDetailsSerializer(serializers.ModelSerializer):
    extensions = ExtExtensionSerializer(many=True, read_only=True, source='extension_task')
    extensions_id = serializers.SerializerMethodField()
    extension_status = serializers.SerializerMethodField()

    class Meta:
        model = TaskDetails
        fields=["id","name","type_of_work","required_material","original_start_date","required_days","original_end_date","end_date","style","extensions_id","extension_status", "extensions"]   

    def get_extensions_id(self, obj):
        unapprove_extension = obj.extension_task.first()
        return unapprove_extension.id if unapprove_extension else None
    
    def get_extension_status(self, obj):
        extension = obj.extension_task.first()
        return extension.approved_status if extension else None
  
   


              






