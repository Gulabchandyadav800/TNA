import logging
from django_filters import rest_framework as filters
from django.db.models import Q
from .models import StyleDetails, TaskDetails, EmployeeDetail, Form68Model,Notification
from django.utils.timezone import now, timedelta
logger = logging.getLogger(__name__)
import re
from django.utils.timezone import now
from datetime import datetime, timedelta


# Filter class for Notification model to filter based on message and created date range
class NotificationFilter(filters.FilterSet):

    # Filter for selecting notification message from distinct choices
    message = filters.ChoiceFilter(
        field_name="message",
        choices=[(msg, msg) for msg in Notification.objects.values_list("message", flat=True).distinct()],
        label="Message"
    )

    # Filter for selecting notifications by created date range
    created = filters.DateFromToRangeFilter(
        field_name="created_at",
        label="Created Date Range"
    )
    class Meta:
        model = Notification
        fields = ['message', 'created']


# Filter class for TaskDetails model to filter task data based on various fields
class TaskDataFilter(filters.FilterSet):
    styleName = filters.CharFilter(field_name="style__style_name", lookup_expr="icontains", label="Style Name")
    qaName = filters.CharFilter(field_name="style__qa__name", lookup_expr="icontains", label="QA Name")
    quantity = filters.CharFilter(field_name='style__quantity', lookup_expr="icontains", label="Quantity")
    vendorName = filters.CharFilter(field_name="style__vendor__name", lookup_expr="icontains", label="Vendor Name")
    creatorName = filters.CharFilter(field_name="style__creator__name", lookup_expr="icontains", label="Creator Name")
    typeofwork = filters.CharFilter(field_name="type_of_work", lookup_expr="icontains", label="Type of Work")
    required_material = filters.CharFilter(field_name="required_material", lookup_expr="icontains",
                                           label="Required Material")
    final_date = filters.CharFilter(field_name="end_date", method="filter_date", label="Final Date")
    original_start_date = filters.CharFilter(field_name="original_start_date", method="filter_date", label="Start Date")
    original_end_date = filters.CharFilter(field_name="original_end_date", method="filter_date", label="End Date")
    ship_date = filters.DateFilter(field_name="style__ship_date", method="filter_date", label="Ship Date")
    ship_date_change_count = filters.NumberFilter(field_name="style__ship_date_change_count", lookup_expr="exact",
                                                  label="Ship Date Change Count")
    extension_approved_status = filters.BooleanFilter(field_name="extension_task__approved_status",
                                                      label="Extension Approved Status")
    form_68_reason = filters.CharFilter(method="filter_form_68_reason", label="Form 68 Reason")
    name = filters.CharFilter(field_name='name', lookup_expr='icontains', label='Descriptions')
    

    # Utility function to convert different date formats into standard format (YYYY-MM-DD)
    def convert_to_standard_date(self, value):
        if not value:
            return None

        try:
            # Match and convert "Mon Jan 01 2025" style format to standard format
            if re.match(r"^[A-Za-z]{3} [A-Za-z]{3} \d{1,2} \d{4}", value):
                return datetime.strptime(value[:15], "%a %b %d %Y").strftime("%Y-%m-%d")

            # Handle "02/01/2025" (MM/DD/YYYY) and "2025-02-01" (YYYY-MM-DD)
            possible_formats = ["%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y", "%d/%m/%Y"]
            for fmt in possible_formats:
                try:
                    return datetime.strptime(value, fmt).strftime("%Y-%m-%d")
                except ValueError:
                    continue

        except Exception as e:
            logger.error(f"Error parsing date: {value}. Exception: {e}")

        return None
    
    # Function to filter task data based on date fields like original_start_date, original_end_date, or final_date
    def filter_date(self, queryset, name, value):
        formatted_date = self.convert_to_standard_date(value)
        if formatted_date:
            return queryset.filter(**{name: formatted_date})
        return queryset
    

    # Function to filter tasks based on Form 68 reason from Form68Model
    def filter_form_68_reason(self, queryset, name, value):
        try:
            extension_ids = Form68Model.objects.filter(reason__icontains=value).values_list("extension_id", flat=True)
            task_ids = TaskDetails.objects.filter(extension_task__id__in=extension_ids).values_list("id", flat=True)
            return queryset.filter(id__in=task_ids).distinct()
        except Exception as e:
            logger.error(f"Error in filtering by form 68 reason: {e}")
            return queryset.none()
    
    # Function to filter tasks based on manager's name (from EmployeeDetail model)
    manager_name = filters.CharFilter(method="filter_manager_name", label="Manager Name")

    def filter_manager_name(self, queryset, name, value):
        try:
            # Filter employee details by manager's name and return tasks related to those employees
            employee_ids = EmployeeDetail.objects.filter(manager__name__icontains=value).values_list("user", flat=True)
            return queryset.filter(style__creator__in=employee_ids)
        except Exception as e:
            logger.error(f"Error in filtering by manager name: {e}")
            return queryset.none()
    
    # Filters for dynamic date range based on startDate, endDate, and selected date field
    date_field = filters.ChoiceFilter(
        choices=[
            ("original_start_date", "Original Start Date"),
            ("original_end_date", "Original End Date"),
            ("end_date", "End Date"),
        ],
        label="Select Date Type",
        method="filter_dynamic_date_range",
    )
    startDate = filters.DateFilter(method="filter_dynamic_date_range", label="Start Date")
    endDate = filters.DateFilter(method="filter_dynamic_date_range", label="End Date")
    
    # Function to filter tasks based on dynamic date range selection (e.g., between start and end dates)
    def filter_dynamic_date_range(self, queryset, name, value):
        try:
            date_field = self.data.get("date_field")
            if not date_field:
                logger.warning("No date field selected for dynamic filtering.")
                return queryset

            start_date = self.convert_to_standard_date(self.data.get("startDate"))
            end_date = self.convert_to_standard_date(self.data.get("endDate"))

            if start_date and end_date:
                return queryset.filter(
                    Q(**{f"{date_field}__gte": start_date}) & Q(**{f"{date_field}__lte": end_date})).distinct()
            elif start_date:
                return queryset.filter(**{f"{date_field}__gte": start_date}).distinct()
            elif end_date:
                return queryset.filter(**{f"{date_field}__lte": end_date}).distinct()

            return queryset
        except Exception as e:
            logger.error(f"Error in filtering by date range: {e}")
            return queryset.none()

    # Filter for different date periods like daily, weekly, and 4 days before
    datePeriod = filters.ChoiceFilter(
        choices=[
            ("daily", "Daily"),
            ("weekly", "Weekly"),
            ("four_days_before", "4 Days Before"),
        ],
        label="Date Period",
        method="filter_by_date_period",
    )
    

    # Function to filter tasks by date periods (daily, weekly, or 4 days before)
    def filter_by_date_period(self, queryset, name, value):
        today = now().date()
        try:
            if value == "daily":
                return queryset.filter(original_end_date=today)
            elif value == "weekly":
                start_date = today - timedelta(days=7)
                return queryset.filter(original_end_date__gte=start_date, original_end_date__lte=today)
            elif value == "four_days_before":
                four_days_ago = today - timedelta(days=4)
                return queryset.filter(original_end_date=four_days_ago)
        except Exception as e:
            logger.error(f"Error in filtering by date period: {e}")
            return queryset.none()

        return queryset

    class Meta:
        model = TaskDetails
        fields = [
            "styleName",
            "qaName",
            "vendorName",
            "creatorName",
            "name",
            "typeofwork",
            "original_start_date",
            "original_end_date",
            "final_date",
            "required_material",
            "ship_date",
            "ship_date_change_count",
            "extension_approved_status",
            "form_68_reason",
            "manager_name",
            "date_field",
            "quantity",
            "startDate",
            "endDate",
            "datePeriod",
        ]
