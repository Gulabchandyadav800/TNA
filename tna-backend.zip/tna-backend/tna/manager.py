from django.contrib.auth.models import BaseUserManager
from django.db import models
from datetime import datetime, timedelta
class Manager(BaseUserManager):

    """Manager for UserProfile"""

    def create_user(self, email, name, password=None):
        if not email:
            raise ValueError('User must have an email address')
        email = self.normalize_email(email)
        user = self.model(email=email, name=name)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, name, password):
        user = self.create_user(email, name, password)
        user.is_superuser = True
        user.is_staff = True
        user.save(using=self._db)
        return user
    
class TaskManager(models.Manager):
    def bulk_create(self, objs, **kwargs):
        for obj in objs:
            # If end_date is not set, use original_end_date or original_start_date
            if not obj.end_date:
                obj.end_date = obj.original_end_date or obj.original_start_date

            # Update original_end_date based on required_days
            if obj.required_days and obj.original_start_date:
                obj.original_end_date = obj.original_start_date + timedelta(days=obj.required_days)       
        return super().bulk_create(objs, **kwargs)    
