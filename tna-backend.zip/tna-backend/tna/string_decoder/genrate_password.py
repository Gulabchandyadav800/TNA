import random
import string

def generate_random_password(self, length=12):
    """
    This function generates a random password of the specified length using a mix of letters, digits, and punctuation characters.
    
    Parameters:
    - length (int): The length of the generated password (default is 12).
    
    Returns:
    - string: A randomly generated password.
    """
    # Defining the characters pool for the password (letters, digits, and punctuation)
    characters = string.ascii_letters + string.digits + string.punctuation
    
    # Randomly selecting characters from the pool and joining them to form the password
    return ''.join(random.choice(characters) for _ in range(length))
