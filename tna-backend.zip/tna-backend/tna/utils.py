# # utils.py
# from datetime import timedelta
# from .models import Relationship, TaskDetails

# def recalculate_child_task_dates(child_task, visited=None):
#     """Recalculate child task dates without affecting parent tasks."""
#     if visited is None:
#         visited = set()

#     if child_task.id in visited:
#         return
#     visited.add(child_task.id)

#     parent_relationships = Relationship.objects.filter(child=child_task)
#     highest_end_date = None
#     for pr in parent_relationships:
#         parent_end_date = (
#             pr.parent.end_date + timedelta(days=pr.offset_days or 0)
#             if pr.parent.end_date else None
#         )
#         if parent_end_date and (highest_end_date is None or parent_end_date > highest_end_date):
#             highest_end_date = parent_end_date

#     if highest_end_date:
#         child_task.original_start_date = highest_end_date
#         child_task.original_end_date = highest_end_date + timedelta(days=child_task.required_days)
#         child_task.end_date = highest_end_date + timedelta(days=child_task.required_days)
#     else:
#         # If no parents remain, revert child's dates
#         child_task.original_end_date = (
#             child_task.original_start_date + timedelta(days=child_task.required_days)
#             if child_task.original_start_date else None
#         )
#         child_task.end_date = child_task.original_end_date

#     child_task.save()

#     # Recurse for children of this task
#     for rel in Relationship.objects.filter(parent=child_task):
#         recalculate_child_task_dates(rel.child, visited)
