# # signals.py
# from django.db.models.signals import post_save
# from django.dispatch import receiver
# from .models import UserNotification
# import requests
# import logging
# logger = logging.getLogger( __name__ )
#
# @receiver(post_save, sender=UserNotification)
# def trigger_get_notification_api(sender, instance, created, **kwargs):
#     if created:
#         # Assuming your API is hosted locally and requires authentication
#         url = 'http://localhost:8000/api/user-notifications/'
#         response = requests.get(url)
#         if response.status_code == 200:
#             logger.info('Notifications fetched successfully %s' % response.status_code)
#             print("Notifications fetched successfully")
#         else:
#             logger.error('Failed to fetch notifications: %s' % response.status_code)
#             print("Failed to fetch notifications", response.status_code)
