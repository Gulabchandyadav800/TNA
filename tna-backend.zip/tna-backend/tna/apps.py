from django.apps import AppConfig


class TnaPpConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tna'

    def ready(self):
        import tna.signals





