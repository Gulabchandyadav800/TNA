from tna.tasks import send_notification_task
from rest_framework import status
from rest_framework.response import Response
import logging
from tna.models import TaskDetails, User, EmployeeDetail

logger = logging.getLogger(__name__)

def send_custom_notification(instance=None, request=None, context=None, **kwargs):
    
    users = set()
    message = kwargs.get("message", "")
    delivery_methods = kwargs.get("delivery_methods", ["app", "email"])
    task = None

    # Fetch task if task_id is provided
    if request:
        task_id = kwargs.get("task_id", request.data.get("sub_task"))
        if task_id:
            try:
                task = TaskDetails.objects.get(id=task_id)
            except TaskDetails.DoesNotExist:
                logger.error(f"Task not found: {request.method} {request.path}")
                return Response(
                    {"error": "Task not found."}, status=status.HTTP_400_BAD_REQUEST
                )

    # Fetch admin users
    admin_users = User.objects.filter(role__role_name="Admin")
    users.update(admin_users)

    # Context-based user handling
    if context in ["CREATE_TNA", "UPDATE_TNA", "EXTENSION", "APPROVE_EXT"]:
        if instance and hasattr(instance, "vendor") and instance.vendor:
            users.add(instance.vendor)
        if instance and hasattr(instance, "qa") and instance.qa:
            users.add(instance.qa)

    # Handling extension contexts
    if context in ["EXTENSION", "APPROVE_EXT"]:
        if task:
            tna_detail = task.style
            if not tna_detail:
                return Response(
                    {"error": "TNA detail not found."}, status=status.HTTP_400_BAD_REQUEST
                )
            creator_id = request.user.id
            if creator_id:
                try:
                    manager = User.objects.get(id=creator_id)
                    users.add(manager)
                    # Assistant merchants
                    employee_details = EmployeeDetail.objects.filter(manager=manager.id)
                    asst_merchants = User.objects.filter(manager__in=employee_details)
                    users.update(asst_merchants)
                except User.DoesNotExist:
                    return Response(
                        {"error": "Manager not found."}, status=status.HTTP_400_BAD_REQUEST
                    )

            user_role_name = request.user.role.role_name
            if user_role_name == "Admin":
                users.update([tna_detail.vendor, tna_detail.qa, tna_detail.creator, *asst_merchants])
            elif user_role_name == "Merchant":
                users.update(admin_users)
            elif user_role_name == "Asst_Merchant":
                extension_days = int(kwargs.get("extension_days", request.data.get("extension_days", 0)))
                if extension_days <= 3:
                    users.update(admin_users)
                    users.add(manager)
                else:
                    users.add(manager)

    # Form68 context handling
    if context == "FORM68":
        if instance:
            vendor = getattr(instance.extension.sub_task.style, "vendor", None)
            if vendor:
                users.add(vendor)

    # Include request user
    if request and request.user:
        users.add(request.user)

    # Default message if not provided
    if not message:
        if context == "CREATE_TNA":
            message = f"A new TNA has been created: {instance.style_name}."
        elif context == "UPDATE_TNA":
            message = f"A new TNA has been updated: {instance.style_name}."
        elif context == "EXTENSION":
            message = f"New extension created: {instance.sub_task.name}."
        elif context == "FORM68":
            message = f"Form68 is submitted for: {instance.extension}."
        elif context == "APPROVE_EXT":
            message = f"The Extension for Task {instance} has been approved."

    # Prepare instance_id
    instance_id = ""
    if instance and hasattr(instance, 'id') and instance.id:
        instance_id += str(instance.id)
    if instance and hasattr(instance, 'form_id') and instance.form_id:
        instance_id += str(instance.form_id)

    # Final user list for notification
    user_emails = [user.email for user in users if user]

    # Send notification
    send_notification_task(list(users), message, delivery_methods, request.user if request else None, instance_id, context)
