from django.utils.timezone import now
from django.db.models.query import QuerySet
from celery import shared_task
from django.db import transaction
from tna.models import Notification, UserNotification, NotificationHistory, NotificationMedium,User

# @shared_task
def send_notification_task(users, message, delivery_methods, sender, instance_id, context) -> None:
    
    with transaction.atomic():
        notification = Notification.objects.create(message=message, sender=sender,notification_type_id=instance_id, Notification_type=context)
        notification_default_state = False
        print(f"Notification sent to {users}")
        for user in users:
            if isinstance(user, QuerySet):
                user_list = user
            else:
                user_list = [user]
            for single_user in user_list:
                user_notification = UserNotification.objects.create(
                    notification=notification,
                    user=single_user   
                    
                )
                NotificationHistory.objects.create(
                    user_notification=user_notification,
                    status=notification_default_state
                )
                for method in delivery_methods:
                    NotificationMedium.objects.create(
                        user_notification_id=user_notification,
                        delivery_method=method,
                        notification_delivered_at=now()
                    )
