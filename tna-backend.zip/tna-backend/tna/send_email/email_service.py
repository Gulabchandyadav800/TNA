import logging
from django.core.mail import send_mail
from django.conf import settings

# Logger setup for tracking email sending process
logger = logging.getLogger(__name__)

# Function to send a welcome email with login details and a password reset link
def send_email(email, username, password, reset_url):
    """
    This function sends a welcome email to a user with their account details,
    including a username, password, and a link to reset their password for the first login.

    Parameters:
    - email: The email address of the recipient.
    - username: The username of the recipient.
    - password: The password assigned to the user.
    - reset_url: The URL to reset the password (used for changed password).

    Returns:
    - bool: True if the email was sent successfully, False otherwise.
    """
    # Email subject and message body (HTML formatted)
    subject = "Welcome to Our Platform - Login Details"
    message = f"""
        <html>
        <body style="color: black;">
            <p>Hello {username},</p>
            <p>Your account has been successfully created.</p>
            <p>Please use the following credentials to log in:</p>
            <p><strong>Username:</strong> {username}</p>
            <p><strong>Password:</strong> {password}</p>
            <p>
                On your first login, you will be required to change your password. 
                <a href="{reset_url}" 
                   style="text-decoration: none; color: blue; font-weight: bold;">
                   Click here to proceed
                </a>.
            </p>
            <p>Regards,</p>
            <p><strong>DKC Exports</strong></p>
        </body>
        </html>
    """

    # Sender email from settings (configured in Django settings)
    from_email = settings.EMAIL_HOST_USER
    recipient_list = [email]

    try:
        # Sending the email using Django's send_mail function
        send_mail(
            subject,
            "Please use an HTML-supported email client to view this message.",
            from_email,
            recipient_list,
            fail_silently=False,
            html_message=message,
        )
        logger.info(f"Welcome email sent to {email}")
        # Return True if email is sent successfully
        return True
    except Exception as e:
        # Log any errors that occur during email sending
        logger.error(f"Failed to send email to {email}: {str(e)}")
        return False  # Return False if there was an error
