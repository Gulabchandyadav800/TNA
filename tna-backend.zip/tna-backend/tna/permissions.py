from rest_framework import permissions
import logging
from .models import UserPermission
logger = logging.getLogger(__name__)

class CustomPermission(permissions.BasePermission):
    """
    Custom permission class that checks the user's permissions based on their role
    and the requested view's model or view permissions.
    """

    def has_permission(self, request, view):
        """
        Checks if the user has permission to access a view based on their role and the requested method.
        
        Parameters:
        - request (Request): The HTTP request object.
        - view (View): The view the user is trying to access.
        
        Returns:
        - bool: True if permission is granted, False otherwise.
        """
        user = request.user
        view_name = getattr(view, "view_name", None)
        logger.info(f"🔍 Checking permissions for user: {user.username} on API View: {view_name}")
        
        if not user.is_authenticated:
            logger.warning("This user is not authenticated.")
            return False

        if user.is_superuser:
            logger.info("This is a superuser, granting full access.")
            return True

        if not user.role:
            logger.warning(f"User {user.username} has no role assigned.")
            return False

        # Check model permissions based on the user's role
        if self.check_model_permissions(request, view, user.role):
            return True
        
        # Check view permissions based on the user's role and the view name
        return self.check_view_permissions(request, view, user.role, view_name)

    def has_object_permission(self, request, view, obj):
        """
        Checks object-level permissions by calling has_permission for the object.
        
        Parameters:
        - request (Request): The HTTP request object.
        - view (View): The view the user is trying to access.
        - obj (Object): The object the permission check is being performed on.
        
        Returns:
        - bool: True if object-level permission is granted, False otherwise.
        """
        return self.has_permission(request, view)

    def check_model_permissions(self, request, view, role):
        """
        Checks if the user has model-level permissions for the requested model based on their role.
        
        Parameters:
        - request (Request): The HTTP request object.
        - view (View): The view the user is trying to access.
        - role (Role): The role of the user requesting access.
        
        Returns:
        - bool: True if model-level permissions are granted, False otherwise.
        """
        model = self.get_model_from_view(view)
        print("model", model)
        
        if not model:
            logger.warning(f"No valid model found for {view.__class__.__name__}")
            return False

        app_label = model._meta.app_label
        model_name = model._meta.model_name
        logger.info(f"🔎 Checking model-level permissions for {app_label}.{model_name}")

        # Map HTTP methods to corresponding permission codename
        method_permission_map = {
            "GET": f"view_{model_name}",
            "POST": f"add_{model_name}",
            "PUT": f"change_{model_name}",
            "PATCH": f"change_{model_name}",
            "DELETE": f"delete_{model_name}",
        }

        required_permission = method_permission_map.get(request.method)
        if not required_permission:
            logger.warning(f"Unknown request method {request.method}, denying access")
            return False
        
        permission_to_check = f"{app_label}.{required_permission}"
        role_permissions = UserPermission.objects.filter(role=role)
        
        # Check if the user has the required model permission
        if role_permissions.filter(permission__codename=required_permission).exists():
            logger.info(f"User {request.user.name} has model permission {permission_to_check}")
            return True
        
        logger.info(f"User {request.user.name} does NOT have model permission {permission_to_check}")
        return False

    def check_view_permissions(self, request, view, role, view_name):
        """
        Checks if the user has view-level permissions for the requested view based on their role.
        
        Parameters:
        - request (Request): The HTTP request object.
        - view (View): The view the user is trying to access.
        - role (Role): The role of the user requesting access.
        - view_name (str): The name of the view being accessed.
        
        Returns:
        - bool: True if view-level permissions are granted, False otherwise.
        """
        if not view_name:
            logger.warning(f"No view_name found for {view.__class__.__name__}")
            return False
        
        method_permission_map = {
            "GET": f"view_{view_name}",
            "POST": f"add_{view_name}",
            "PUT": f"change_{view_name}",
            "PATCH": f"change_{view_name}",
            "DELETE": f"delete_{view_name}",
        }

        required_permission = method_permission_map.get(request.method)
        if not required_permission:
            logger.warning(f"Unknown request method {request.method}, denying access")
            return False
        
        logger.info(f"Checking view-level permissions for {view_name} -> Required: {required_permission}")
        role_permissions = UserPermission.objects.filter(role=role)

        # Check if the user has the required view permission
        if role_permissions.filter(permission__codename=required_permission).exists():
            logger.info(f"User {request.user.name} has view permission {required_permission}")
            return True
        
        logger.info(f"User {request.user.name} does NOT have view permission {required_permission}")
        return False

    def get_model_from_view(self, view):
        """
        Retrieves the model associated with the given view based on its queryset or serializer class.
        
        Parameters:
        - view (View): The view to extract the model from.
        
        Returns:
        - model (Model): The model associated with the view, or None if not found.
        """
        if hasattr(view, "queryset") and view.queryset is not None:
            return view.queryset.model
        if hasattr(view, "serializer_class") and view.serializer_class is not None:
            return view.serializer_class.Meta.model
        return None
