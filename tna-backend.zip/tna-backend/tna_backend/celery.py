# your_project_name/celery.py

import os
from celery import Celery

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tna_backend.settings")

app = Celery("tna_backend")

app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()
