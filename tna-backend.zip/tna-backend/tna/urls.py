# urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import *

router = DefaultRouter()
# Registering viewsets for different models
router.register(r'roles', RoleViewSet)  # Role management
router.register(r'extensions', ExtensionViewSet)  # Extension requests
router.register(r'employees', EmployeeDetailViewSet)  # Employee details
router.register(r'fabric-details', FabricDetailViewSet)  # Fabric-related details
router.register(r'users', UsersViewSet)  # User management
router.register(r'tna', StyleDetailsViewSet)  # Create and update TNA
router.register(r'notification', UserNotificationViewSet)  # User notifications
router.register(r'user-permissions', UserPermissionViewSet)  # User role permissions

urlpatterns = [
    # User authentication and management
    path('add-users/', AddUsersView.as_view(), name='add-users'),  # Add new users
    path('login/', LoginView.as_view(), name='login'),  # User login
    path('reset-password/', PasswordResetView.as_view(), name='reset-password'),  # Password reset
    path('change-password/<uidb64>/', ChangePasswordView.as_view(), name='change-password'), 

    # API routes registered with the router
    path('', include(router.urls)),

    # Approvals & Updates
    path('approve-extension/<int:pk>/', ApproveExtensionView.as_view(), name='approve-extension'), # Approve extension requests
    path('update-user/<int:pk>/', UpdateUserAPIView.as_view(), name='update-user'),  # Update user details
    path('extension-approve-details/<int:tna_id>/', ExtensionApproveDetailsView.as_view(), name='extension-approve-details'),# extension approve details url

    # Lists of different user roles
    path('get-qa/', QaListAPIView.as_view(), name='qa-list'),  # Get QA list
    path('get-extensions/', ExtensionListAPIView.as_view(), name='extension-list'),  # Get extension list
    path('get-vendor/', VendorListAPIView.as_view(), name='vendor-list'),  # Get vendors list
    path('get-manager/', ManagerListAPIView.as_view(), name='Manager-list'),  # Get managers list

    # Work-related APIs
    path('get-typeofwork/', TypeofWorkViewSet.as_view(), name='get-typeofwork'),  # Get types of work
    path('delete-tna/<int:pk>/', DeleteStyleDetailsViewSet.as_view(), name='delete-tna'),  # Soft delete a TNA entry

    # Notifications
    path('read-notifications/<int:pk>/', ReadNotificationViewSet.as_view(), name='read-notification'), # Mark notification as read or unread

    # Style details and lists
    path('style-list/', StyleDisplayView.as_view(), name='style-list'),  # Get list of styles
    path('style-details/<int:style_id>/', StyleDisplayView.as_view(), name='style-details-detail'), # Get details of a specific style

    # QA Calendar
    path('qa-calendar/', QAcalendarListAPIView.as_view(), name='qa-calendar'),  # T&A list for only QA

    # User profile and dashboard
    path('user-list/', UserListView.as_view(), name='user-list'),  # Get list of users
    path("profile/", UserProfileView.as_view(), name="user-profile"),  # User profile details
    path('dashboard/', DashboardAPIView.as_view(), name='dashboard'),  # Dashboard data

    # Form 68 related APIs
    path('form68/', CreateForm68APIView.as_view(), name='form68-create'),  # Create a Form 68 entry
    path('form68-list/', ListForm68APIView.as_view(), name='form68-list'),  # List Form 68 entries
    path('form68/<int:id>/', GetForm68APIView.as_view(), name='form68-get'),  # Get details of a Form 68 entry

    #History
    path('history/<int:style_id>/', HistoryAPIView.as_view(), name='history-by-style'),# tna history
    
]
