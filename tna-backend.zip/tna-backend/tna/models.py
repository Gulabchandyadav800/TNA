from django.db import models
from django.contrib.auth.models import AbstractUser
from datetime import datetime, timedelta
from django.utils import timezone
from tna.manager import Manager,TaskManager
from simple_history.models import HistoricalRecords
from django.db.models import Max
from django.contrib.auth.models import User, Permission


# Base model to automatically include 'created_at' and 'updated_at' fields
class TimestampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        abstract = True

# Model for defining user roles (e.g., Admin, User)
class Role(TimestampedModel):
    role_name = models.CharField(max_length=255)

    def __str__(self):
        return self.role_name


# Custom User model that extends AbstractUser
class User(AbstractUser):
    email = models.EmailField(unique=True)
    username = models.EmailField(null=True, blank=True)
    name = models.CharField(max_length=255, null=True, blank=True)
    role = models.ForeignKey(Role, on_delete=models.CASCADE, null=True, blank=True)
    department = models.CharField(max_length=255, null=True, blank=True)
    active= models.BooleanField(default=False)
    designation = models.CharField(max_length=255, null=True, blank=True)
    force_password_change = models.BooleanField(default=True)

    objects = Manager()
    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["name"]

    def __str__(self):
        return self.email




# Model to track employees and their managers
class EmployeeDetail(TimestampedModel):
    employee_id = models.AutoField(primary_key=True)
    manager = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    user = models.ManyToManyField(User, related_name="manager")
    history = HistoricalRecords()

    def __str__(self):
        if self.user.exists():
            user_name = self.user.first().name if self.user.first().name else 'Unknown User'
            return user_name
        return "No User Assigned"


# Model to store tna details (related to production and vendors)
class StyleDetails(TimestampedModel):
    style_name = models.CharField(max_length=255)
    qa = models.ForeignKey(User,related_name='qa_users', on_delete=models.CASCADE)
    vendor = models.ForeignKey(User,related_name='vendor_users', on_delete=models.CASCADE)
    creator = models.ForeignKey(User, related_name='creator_users', on_delete=models.CASCADE)
    order_place_date = models.DateField()
    ship_date = models.DateField()
    quantity = models.IntegerField()
    average_production_per_day = models.IntegerField()
    stitching = models.IntegerField()
    machine_required = models.IntegerField()
    is_active = models.BooleanField(default=False)
    ship_date_change_count = models.PositiveIntegerField(default=0)
    po_details = models.CharField(max_length=500, null=True, blank=True)
    history = HistoricalRecords()

    def __str__(self):
        return self.style_name
    
    class Meta:
        ordering = ["id"]

    def save(self, *args, **kwargs):
        if self.pk:
            try:
                old_instance = StyleDetails.objects.get(pk=self.pk)
                if old_instance.ship_date != self.ship_date:
                    self.ship_date_change_count += 1
            except StyleDetails.DoesNotExist:
                pass  # If object doesn't exist, it's a new entry
        super().save(*args, **kwargs)


# TaskDetails model for tracking production tasks under a style
class TaskDetails(TimestampedModel):
    
    name = models.CharField(max_length=255)
    type_of_work = models.CharField(max_length=255)
    required_material = models.CharField(max_length=255)
    original_start_date = models.DateField()
    index = models.IntegerField(null=True, blank=True)
    required_days = models.IntegerField(null=True, blank=True)
    original_end_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    style = models.ForeignKey(StyleDetails, related_name='task_style', on_delete=models.CASCADE)
    flag = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(default=timezone.now)
    history = HistoricalRecords()

    class Meta:
        ordering = ["id"]  
    
    objects = TaskManager()    

    def __str__(self):
        return self.name
    
   

# Relationship model to manage task dependencies
class Relationship(models.Model):
    parent = models.ForeignKey(TaskDetails, related_name='task_parents',on_delete=models.CASCADE)
    child = models.ForeignKey(TaskDetails, related_name='task_child', on_delete=models.CASCADE)
    offset_days =models.IntegerField(null=True,blank=True)
    history = HistoricalRecords()


    def __str__(self):
        return f"Relationship of{self.parent.name}" + f"{self.child.name}"


# Extension model for handling task extensions
class Extension(TimestampedModel):
    id = models.AutoField(primary_key=True)
    sub_task = models.ForeignKey(
        'TaskDetails', on_delete=models.CASCADE, related_name="extension_task"
    )
    approved_status = models.BooleanField(default=False)
    extension_days = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    requested_by = models.ForeignKey(
        'User',
        related_name="requested_extensions",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    approved_by = models.ForeignKey(
        'User',
        related_name="approved_extensions",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    reason = models.TextField(null=True, blank=True)
    history = HistoricalRecords()

    class Meta:
        ordering = ["id"]

    def save(self, *args, **kwargs):
        super(Extension, self).save(*args, **kwargs)

        # if self.approved_status:
        print("Starting extension update for:", self.sub_task.name)
        self.extend_task_and_children(self.sub_task, self.extension_days, visited=set())

    def extend_task_and_children(self, parent_task, extension_days, visited):
        """ Recursively update parent and child tasks considering multiple parents and offset days """
        if parent_task.id in visited:
            print(f"Task {parent_task.name} already visited. Skipping to avoid recursion.")
            return  # Avoid circular recursion
        visited.add(parent_task.id)

        print(f"Updating parent task: {parent_task.name}")
        # Update parent task
        parent_task.end_date = (
            parent_task.end_date + timedelta(days=extension_days)
            if parent_task.end_date else None
        )
        parent_task.save()
        print(f"Parent task updated: {parent_task.name}")

        # Fetch child tasks via Relationship model
        child_relationships = Relationship.objects.filter(parent=parent_task)
        print(f"Found {child_relationships.count()} child relationships for {parent_task.name}.")

        for relation in child_relationships:
            child_task = relation.child
            print(f"Evaluating child task: {child_task.name}")

            # Get all parents of the child task
            parent_relationships = Relationship.objects.filter(child=child_task)

            # Calculate the highest end_date among all parents + offset_days
            highest_end_date = None
            for pr in parent_relationships:
                parent_end_date = pr.parent.end_date + timedelta(days=pr.offset_days or 0) if pr.parent.end_date else None
                if parent_end_date and (highest_end_date is None or parent_end_date > highest_end_date):
                    highest_end_date = parent_end_date
            
            print("timedelta(days=child_task.required_days)",timedelta(days=child_task.required_days))
            print("child_task.required_days",child_task.required_days)
            if highest_end_date:
                child_task.original_start_date = highest_end_date
                child_task.original_end_date = (
                    highest_end_date + timedelta(days=child_task.required_days)
                    if child_task.required_days else highest_end_date
                )
                child_task.end_date = (
                    highest_end_date + timedelta(days=child_task.required_days)
                    if child_task.required_days else highest_end_date
                )
                child_task.save()
                print(f"Child task {child_task.name} updated with new dates.")

                # Recursive call for further child tasks
                self.extend_task_and_children(child_task, 0, visited)

    def __str__(self):
        return self.sub_task.name

# Notification model for user alerts
class Notification(TimestampedModel):
    id = models.AutoField(primary_key=True)
    message = models.TextField()
    history = HistoricalRecords()
    is_read = models.BooleanField(default=False)
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sender',null=True, blank=True)
    Notification_type = models.CharField(max_length=255, null=True, blank=True)
    notification_type_id = models.IntegerField(null=True, blank=True)

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return self.message[:50]


# UserNotification model for associating notifications with users
class UserNotification(TimestampedModel):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    notification = models.ForeignKey(Notification, on_delete=models.CASCADE, related_name='user_notifications')
    history = HistoricalRecords()

    class Meta:
        ordering = ["id"]

    def __str__(self):
        if self.user.name:
            return self.user.name

# NotificationHistory model for tracking the history of notification statuses
class NotificationHistory(TimestampedModel):
    id = models.AutoField(primary_key=True)
    user_notification = models.ForeignKey(UserNotification, on_delete=models.CASCADE)
    status = models.BooleanField()
    history = HistoricalRecords()

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return f"History of {self.user_notification}"


# Model to track the delivery medium of notifications (e.g., email, SMS)
class NotificationMedium(TimestampedModel):
    id = models.AutoField(primary_key=True)
    user_notification_id = models.ForeignKey(UserNotification, on_delete=models.CASCADE)
    delivery_method = models.CharField(max_length=100)
    notification_delivered_at = models.DateTimeField(timezone.now())
    history = HistoricalRecords()

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return "self.user_notification_id.notification.message"


# Model for Form 68, which tracks extensions requested for tasks
class Form68Model(TimestampedModel):
    form_id = models.AutoField(primary_key=True)
    amount = models.IntegerField(null=True, blank=True)
    extension = models.ForeignKey(Extension, on_delete=models.CASCADE, related_name='form_extensions')
    reason = models.TextField()
    history = HistoricalRecords()

    class Meta:
        db_table = 'form-68'
        verbose_name = 'Form 68'
        verbose_name_plural = 'Form 68'
        ordering = ["form_id"]

    def __str__(self):
        return self.extension.sub_task.name


# Model for fabric details associated with a style order
class FabricDetail(TimestampedModel):
    id = models.AutoField(primary_key=True)
    style_details = models.ForeignKey(StyleDetails, on_delete=models.CASCADE)
    fabric_name = models.CharField(max_length=255)

    class Meta:
        unique_together = ("style_details", "fabric_name")

    def __str__(self):
        return self.fabric_name


# Model for different types of work in production (e.g., stitching, QA checks)
class TypeOfWork(models.Model):
    type_of_work = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return self.type_of_work


# Model to manage user permissions based on their role and associated view access
class UserPermission(models.Model):
    role = models.ForeignKey(Role, on_delete=models.CASCADE, related_name="permissions", null=True, blank=True)
    permission = models.ManyToManyField(Permission, related_name='user_permissions')
    view_name = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        permissions_names = ", ".join([perm.name for perm in self.permission.all()])
        return f"{self.role} - {permissions_names} - {self.view_name}"

    def has_permission(self, permission_codename, view_name=None):

        if view_name:
            return self.permission.filter(codename=permission_codename, user_permissions__view_name=view_name).exists()
        return self.permission.filter(codename=permission_codename).exists()
