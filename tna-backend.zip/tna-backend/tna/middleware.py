from tna.models import Extension
from django.urls import resolve

class ExtensionTriggerMiddleware:
    """Trigger extension logic only when StyleDetails is updated."""
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        # Check if the current view is for updating StyleDetails
        try:
            resolver_match = resolve(request.path_info)
            if resolver_match.url_name == 'styledetails-detail' and request.method in ['PUT', 'PATCH']:
                # Trigger extension logic after updating StyleDetails 
                approved_extensions = Extension.objects.filter(approved_status=True)
                for extension in approved_extensions:
                    extension.save()
        except Exception as e:
            print(f"Middleware error: {e}")

        return response
