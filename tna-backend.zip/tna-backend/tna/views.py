import logging
from django.db import transaction
from django.db.models import Count, Q
from django.utils.encoding import force_str, force_bytes
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from rest_framework import generics, status, viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.pagination import PageNumberPagination
from rest_framework_simplejwt.tokens import RefreshToken
from django_filters.rest_framework import DjangoFilterBackend
from .filters import NotificationFilter, TaskDataFilter
from .models import *
import time
from django.conf import settings
from django.db.models import Prefetch
from .permissions import CustomPermission
from .serializers import *
from .notifications import send_custom_notification
from tna.string_decoder.genrate_password import generate_random_password
from tna.send_email.email_service import send_email
logger = logging.getLogger(__name__)
User = get_user_model()



# Add user view
class AddUsersView(generics.CreateAPIView):
    serializer_class = UserSerializer
    def create(self, request, *args, **kwargs):
        logger.info("API request: %s %s", request.method, request.path)
        try:
            response_data = super().create(request, *args, **kwargs)
            logger.info("User created successfully: %s", response_data.data)
            response = {
                "message": "User added successfully.",
                "error": False,
                "status": status.HTTP_201_CREATED,
                "data": response_data.data,
            }
            return Response(response, status=status.HTTP_201_CREATED)

        except ValidationError as e:
            logger.error("Validation error during user creation: %s", str(e))
            response = {
                "message": "Validation error occurred.",
                "error": True,
                "status": status.HTTP_400_BAD_REQUEST,
                "data": e.detail,
            }
            return Response(response, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            logger.error("Unexpected error during user creation: %s", str(e))
            response = {
                "message": "An unexpected error occurred.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    # Send email to user with generated password
    def perform_create(self, serializer):
        generated_password = generate_random_password(self)
        user = serializer.save(password=make_password(generated_password), force_password_change=True)
        uid = urlsafe_base64_encode(force_bytes(user.id))
        reset_url = f"{settings.FRONTEND_URL}?id={uid}/"
        send_email(user.email, user.name, generated_password,reset_url)


# User login view.
class LoginView(APIView):
    def post(self, request):
        logger.info("API request: %s %s", request.method, request.path)
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data["email"]
            uid = urlsafe_base64_encode(force_bytes(user.id))
            reset_url = f"{settings.FRONTEND_URL}?id={uid}/"
            if user.force_password_change:
                logger.warning("User ID %s must change their password before logging in.", user.id)
                return Response(
                    {
                        "message": "Please change your password before logging in.",
                        "error": True,
                        "status": status.HTTP_403_FORBIDDEN,
                        "data": {
                            "reset_url":reset_url
                        },
                    },
                    status=status.HTTP_403_FORBIDDEN,
                )
            refresh = RefreshToken.for_user(user)
            access_token = refresh.access_token
            access_token.set_exp(lifetime=timedelta(hours=2))
            refresh.set_exp(lifetime=timedelta(days=7))
            user_id = user.id
            user_type = user.role.role_name if user.role else ""

            response = {
                "message": "User login successful.",
                "error": False,
                "code": status.HTTP_200_OK,
                "data": {
                    "user_role": user_type,
                    "access_token": str(access_token),
                    "refresh_token": str(refresh),
                },
            }
            logger.info("Login successful for user ID: %s", user_id)
            return Response(response, status=status.HTTP_200_OK)
        logger.warning("Invalid login attempt: %s", serializer.errors)
        return Response(
            {
                "message": "Invalid input.",
                "error": True,
                "status": status.HTTP_400_BAD_REQUEST,
                "data": serializer.errors,
            },
            status=status.HTTP_400_BAD_REQUEST,
        )

# Change password view.
class ChangePasswordView(APIView):
    print("uuuuuuuuuuuuuuuuu")
    def put(self, request, uidb64):
        # print(f"Changing password for user with uid: {uidb64}")
        try:
           
            uid = force_str(urlsafe_base64_decode(uidb64))
            print(f"Resetting password for user with uid: {uid}")
            user = User.objects.get(pk=uid)
        except (User.DoesNotExist, ValueError, TypeError):
            logger.warning("Invalid password reset attempt with uid: %s", uidb64)
            return Response({"message": "Invalid or expired password reset link."}, status=status.HTTP_400_BAD_REQUEST)
        if not user.force_password_change:
            return Response({"message": "Password change is not required."}, status=status.HTTP_400_BAD_REQUEST)
        old_password = request.data.get("old_password")
        new_password = request.data.get("new_password")
        confirm_password = request.data.get("confirm_password")

        if not old_password or not new_password or not confirm_password:
            return Response({"message": "All fields are required."}, status=status.HTTP_400_BAD_REQUEST)
        if not check_password(old_password, user.password):
            return Response({"message": "Incorrect old password."}, status=status.HTTP_400_BAD_REQUEST)
        if new_password != confirm_password:
            return Response({"message": "New passwords do not match."}, status=status.HTTP_400_BAD_REQUEST)
        if len(new_password) < 8:
            return Response({"message": "Password must be at least 8 characters long."}, status=status.HTTP_400_BAD_REQUEST)
        user.password = make_password(new_password)
        user.force_password_change = False
        user.save()
        logger.info("User ID %s successfully changed their password.", user.id)
        return Response(
            {
                "message": "Password changed successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                
            },
            status=status.HTTP_200_OK,
        )

# Password reset view.
class PasswordResetView(APIView):
    def post(self, request):
        serializer = PasswordResetSerializer(data=request.data)
        if serializer.is_valid():
            user_id = serializer.validated_data['user_id']
            try:
                user = User.objects.get(id=user_id)
            except User.DoesNotExist:
                logger.warning(f"Password reset failed: User ID {user_id} not found. Requested by {request.user}")
                return Response({
                    "status": "error",
                    "message": "User not found."
                }, status=status.HTTP_404_NOT_FOUND)
            generated_password = generate_random_password(self)
            uid = urlsafe_base64_encode(force_bytes(user.id))
            reset_url = f"{settings.FRONTEND_URL}?id={uid}/"
            user.password = make_password(generated_password)
            user.force_password_change = True
            user.save()
            send_email(user.email, user.name, generated_password, reset_url)
            logger.info(f"Password reset successful for User ID: {user.id} ({user.name}). Email sent.")

            return Response({
                "status": "success",
                "message": f"Password reset successful for {user.name}. A reset email has been sent.",
                "reset_url": reset_url
            }, status=status.HTTP_200_OK)
        logger.warning(f"Password reset failed. Errors: {serializer.errors} - Requested by {request.user}")
        return Response({
            "status": "error",
            "message": "Password reset failed",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)



# Role view.
class RoleViewSet(viewsets.ModelViewSet):
    queryset = Role.objects.all()
    serializer_class = RoleSerializer

    # permission_classes = [IsInGroup]
    # required_groups = ['Admin', 'Editor']

    def initial(self, request, *args, **kwargs):
        logger.info("API request: %s %s", request.method, request.path)
        super().initial(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        logger.info("Fetching roles list")
        try:
            roles = self.get_queryset()
            serializer = self.get_serializer(roles, many=True)
            response = {
                "message": "Roles fetched successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": serializer.data,
            }
            logger.info("Roles fetched successfully.")
            return Response(response, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching roles: %s", str(e))
            response = {
                "message": "Failed to fetch roles.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": e.detail,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def create(self, request, *args, **kwargs):
        logger.info("Creating a new role")
        try:
            response_data = super().create(request, *args, **kwargs)
            response = {
                "message": "Role created successfully.",
                "error": False,
                "status": status.HTTP_201_CREATED,
                "data": response_data.data,
            }
            logger.info("Role created successfully.")
            return Response(response, status=status.HTTP_201_CREATED)
        except Exception as e:
            logger.error("Error creating role: %s", str(e))
            response = {
                "message": "Failed to create role.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    # Update role view.
    def update(self, request, *args, **kwargs):
        logger.info("Updating role with ID: %s", kwargs.get('pk'))
        try:
            response_data = super().update(request, *args, **kwargs)
            response = {
                "message": "Role updated successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": response_data.data,
            }
            logger.info("Role updated successfully.")
            return Response(response, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error updating role: %s", str(e))
            response = {
                "message": "Failed to update role.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    # Delete role view.
    def destroy(self, request, *args, **kwargs):
        logger.info("Deleting role with ID: %s", kwargs.get('pk'))
        try:
            instance = self.get_object()
            instance.delete()
            response = {
                "message": "Role deleted successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": None,
            }
            logger.info("Role deleted successfully.")
            return Response(response, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error deleting role: %s", str(e))
            response = {
                "message": "Failed to delete role.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# Extension view.
class ExtensionViewSet(viewsets.ModelViewSet):
    queryset = Extension.objects.all()
    serializer_class = ExtensionSerializer
    
    # extension request view.
    def list(self, request, *args, **kwargs):
        logger.info("API request: %s %s", request.method, request.path)
        try:
            approved_extensions = self.queryset.filter(approved_status=True)
            extension_days_data = approved_extensions.values_list("extension_days", flat=True)
            paginator = PageNumberPagination()
            paginator.page_size = 10
            paginated_data = paginator.paginate_queryset(extension_days_data, request)
            logger.info("Extensions fetched successfully.")
            return paginator.get_paginated_response({
                "message": "Extensions fetched successfully.",
                "error": False,
                "code": status.HTTP_200_OK,
                "data": {"extension_days": paginated_data}
            })
        except Exception as e:
            logger.error("Error fetching extensions: %s", str(e))
            return Response({
                "message": "Failed to fetch extensions.",
                "error": True,
                "code": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
   # Create extension view.
    def create(self, request, *args, **kwargs):
        logger.info("API request: %s %s", request.method, request.path)

        data = request.data
        data["requested_by"] = request.user.id
        extension_days = int(data.get("extension_days", 0))
        sub_task = data.get("sub_task")

        if not sub_task:
            return Response({
                "message": "Task ID is required.",
                "error": True,
                "status": status.HTTP_400_BAD_REQUEST,
                "data": None
            }, status=status.HTTP_400_BAD_REQUEST)

        # Check if there is any unapproved extension for the task
        pending_extension = self.get_queryset().filter(
            sub_task_id=sub_task,
            approved_status=False
        ).exists()
        print(f"pending_extension: {pending_extension}")
        if pending_extension:
            logger.warning("Task %s already has a pending extension.", sub_task)
            return Response({
                "message": "Cannot add a new extension until the previous extension is approved.",
                "error": True,
                "status": status.HTTP_400_BAD_REQUEST,
                "data": None
            }, status=status.HTTP_400_BAD_REQUEST)

        today = now().date()
        existing_extension_today = self.get_queryset().filter(
            sub_task=sub_task,
            created_at__date=today
        ).exists()

        if existing_extension_today:
            logger.warning("Task %s already has an extension for today.", sub_task)
            return Response({
                "message": "This task already has an extension for today.",
                "error": True,
                "status": status.HTTP_400_BAD_REQUEST,
                "data": None
            }, status=status.HTTP_400_BAD_REQUEST)

        if extension_days <= 3 and request.user.role.role_name == "Merchant":
            data["approved_status"] = True

        serializer = self.get_serializer(data=data)
        try:
            serializer.is_valid(raise_exception=True)
            instance = serializer.save(
                approved_status=data.get("approved_status", False),
                requested_by=request.user
            )

            send_custom_notification(instance=instance, request=request, context="EXTENSION", sender=request.user)

            if instance.approved_status:
                send_custom_notification(instance=instance, request=request, context="APPROVE_EXT", sender=request.user)
                logger.info("Extension approved successfully: %s", serializer.data)

            logger.info("Extension created successfully: %s", serializer.data)

            return Response({
                "message": "Extension added successfully.",
                "error": False,
                "status": status.HTTP_201_CREATED,
                "data": {"extension": serializer.data},
            }, status=status.HTTP_201_CREATED)

        except ValidationError as e:
            logger.warning("Validation error: %s", e.detail)
            return Response({
                "message": "Validation failed.",
                "error": True,
                "status": status.HTTP_400_BAD_REQUEST,
                "data": e.detail
            }, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            logger.error("Error creating extension: %s", str(e))
            return Response({
                "message": "An unexpected error occurred while creating the extension.",
                "error": str(e),
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



# Emplyee View
class EmployeeDetailViewSet(viewsets.ModelViewSet):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer
    # permission_classes = [IsAuthenticated, CustomPermission]

    def initial(self, request, *args, **kwargs):
        logger.info("API request: %s %s" % (request.method, request.path))
        super().initial(request, *args, **kwargs)

    def list(self, request, *args, **kwargs):
        logger.info("Fetching employee details list")
        try:
            queryset = self.filter_queryset(self.get_queryset())
            paginator = PageNumberPagination()
            paginator.page_size = 10
            paginated_data = paginator.paginate_queryset(queryset, request)
            serializer = self.get_serializer(paginated_data, many=True)

            response = {
                "message": "Employee details fetched successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": serializer.data,
            }
            logger.info("Employee details fetched successfully.")
            return paginator.get_paginated_response(response)
        except Exception as e:
            logger.error("Error fetching employee details: %s", str(e))
            response = {
                "message": "Failed to fetch employee details.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    # Create employee view.
    def create(self, request, *args, **kwargs):
        logger.info("Creating a new employee detail")
        try:
            response_data = super().create(request, *args, **kwargs)
            response = {
                "message": "Employee detail created successfully.",
                "error": False,
                "status": status.HTTP_201_CREATED,
                "data": response_data.data,
            }
            logger.info("Employee detail created successfully.")
            return Response(response, status=status.HTTP_201_CREATED)
        except Exception as e:
            logger.error("Error creating employee detail: %s", str(e))
            response = {
                "message": "Failed to create employee detail.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    # Update employee view.
    def update(self, request, *args, **kwargs):
        logger.info("Updating employee detail with ID: %s", kwargs.get('pk'))
        try:
            response_data = super().update(request, *args, **kwargs)
            response = {
                "message": "Employee detail updated successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": response_data.data,
            }
            logger.info("Employee detail updated successfully.")
            return Response(response, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error updating employee detail: %s", str(e))
            response = {
                "message": "Failed to update employee detail.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    # Delete employee view.
    def destroy(self, request, *args, **kwargs):
        logger.info("Deleting employee detail with ID: %s", kwargs.get('pk'))
        try:
            instance = self.get_object()
            instance.delete()
            response = {
                "message": "Employee detail deleted successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": None,
            }
            logger.info("Employee detail deleted successfully.")
            return Response(response, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error deleting employee detail: %s", str(e))
            response = {
                "message": "Failed to delete employee detail.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# Fabric View
class FabricDetailViewSet(viewsets.ModelViewSet):
    queryset = FabricDetail.objects.all()
    serializer_class = FabricDetailSerializer

    def create(self, request, *args, **kwargs):
        logger.info("API request: %s %s" % (request.method, request.path))
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            self.perform_create(serializer)
            response = {
                "message": "Fabric detail created successfully",
                "error": False,
                "status": status.HTTP_201_CREATED,
                "data": serializer.data,
            }
            return Response(response, status=status.HTTP_201_CREATED)
        response = {
            "message": "Validation failed",
            "error": True,
            "status": status.HTTP_400_BAD_REQUEST,
            "data": serializer.errors,
        }
        return Response(response, status=status.HTTP_400_BAD_REQUEST)
    # Update fabric view.
    def update(self, request, *args, **kwargs):
        logger.info("API request: %s %s" % (request.method, request.path))
        partial = kwargs.pop("partial", False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        if serializer.is_valid():
            self.perform_update(serializer)
            response = {
                "message": "Fabric detail updated successfully",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": serializer.data,
            }
            return Response(response, status=status.HTTP_200_OK)
        response = {
            "message": "Update failed",
            "error": True,
            "status": status.HTTP_400_BAD_REQUEST,
            "data": serializer.errors,
        }
        return Response(response, status=status.HTTP_400_BAD_REQUEST)
    
    # List fabric view.
    def list(self, request, *args, **kwargs):
        logger.info("API request: %s %s" % (request.method, request.path))
        queryset = self.filter_queryset(self.get_queryset())
        paginator = PageNumberPagination()
        paginator.page_size = 10
        paginated_data = paginator.paginate_queryset(queryset, request)
        serializer = self.get_serializer(paginated_data, many=True)
        response = {
            "message": "Fabric details fetched successfully",
            "error": False,
            "status": status.HTTP_200_OK,
            "data": serializer.data,
        }
        return paginator.get_paginated_response(response)
    
    # Delete fabric view.
    def destroy(self, request, *args, **kwargs):
        logger.info("API request: %s %s" % (request.method, request.path))
        instance = self.get_object()
        self.perform_destroy(instance)
        response = {
            "message": "Fabric detail deleted successfully",
            "error": False,
            "status": status.HTTP_204_NO_CONTENT,
        }
        return Response(response, status=status.HTTP_204_NO_CONTENT)

# User view
class UsersViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UsersSerializer

    def initial(self, request, *args, **kwargs):
        logger.info("API request: %s %s" % (request.method, request.path))
        super().initial(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        logger.info("API request: %s %s" % (request.method, request.path))
        instance = self.get_object()
        instance.active = False
        response = {
            "message": "User deleted successfully",
            "error": False,
            "status": status.HTTP_204_NO_CONTENT,
        }
        return Response(response, status=status.HTTP_204_NO_CONTENT)    


# Extension approveviews
class ApproveExtensionView(APIView):

    def patch(self, request, pk):
        try:
            exts = Extension.objects.get(id=pk)
            extension_days = exts.extension_days
            user_role = request.user.role.role_name
            if user_role == "Asst_Merchant" and  extension_days <= 3:
                return Response(
                    {
                        "message": "Only admin or Manager can approve this extension",
                        "error": True,
                        "status": status.HTTP_403_FORBIDDEN,
                        "data": None
                    },
                    status=status.HTTP_403_FORBIDDEN
                )
            elif extension_days > 3 and user_role != "Admin":
                return Response(
                    {
                        "message": "Only admin can approve extensions greater than 3 days.",
                        "error": True,
                        "status": status.HTTP_403_FORBIDDEN,
                        "data": None
                    },
                    status=status.HTTP_403_FORBIDDEN
                )
            else:
                serializer = ApproveExtensionSerializer(data=request.data, partial=True)
                if serializer.is_valid():
                    approved_status = serializer.validated_data["approved_status"]
                else:
                    return Response(
                        {
                            "message": "Validation failed",
                            "error": True,
                            "status": status.HTTP_400_BAD_REQUEST,
                            "data": serializer.errors
                        },
                        status=status.HTTP_400_BAD_REQUEST
                    )
            Extension.objects.filter(id=pk).update(
                approved_status=approved_status,approved_by=request.user
            )
            send_custom_notification(instance=exts, request=request, context="APPROVE_EXT")
            logger.info("Extension approved: ID %s by user %s" % (pk, request.user))
            return Response(
                {
                    "message": "Extension approved and updated successfully.",
                    "error": False,
                    "status": status.HTTP_201_CREATED,
                    "data": {
                        "extension_id": pk,
                        "approved_status": approved_status,

                    }
                },
                status=status.HTTP_201_CREATED
            )

        except Extension.DoesNotExist:
            logger.error("Extension with ID %s does not exist" % pk)
            return Response(
                {
                    "message": "Extension not found",
                    "error": True,
                    "status": status.HTTP_404_NOT_FOUND,
                    "data": None
                },
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            logger.error("Error: %s" % str(e))
            return Response(
                {
                    "message": "Internal server error",
                    "error": True,
                    "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                    "data": str(e)
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

       

        

# Notification view 
class UserNotificationViewSet(viewsets.ModelViewSet):
    queryset = Notification.objects.all().order_by('id')
    serializer_class = NotificationSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_class = NotificationFilter

    # List notification view. 
    def get_queryset(self):
        user = self.request.user
        logger.info("Fetching notifications for user: %s", user)

        if user.role.role_name == "Admin":
            logger.info("Admin user fetching all notifications.")
            return Notification.objects.all().order_by('-created_at')
        else:
            logger.info("Regular user fetching their own notifications.")
            user_notifications = UserNotification.objects.filter(user=user)
            return Notification.objects.filter(id__in=[n.notification.id for n in user_notifications]).order_by('-created_at')

# QA list view
class QaListAPIView(APIView):
    def get(self, request, *args, **kwargs):
        logger.info("Fetching QA users")
        try:
            # Filter users with the role 'QA'
            qa_users = User.objects.filter(role__role_name="QA")
            qa_data = qa_users.values("id", "name")

            response = {
                "message": "QA users fetched successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": list(qa_data),
            }
            logger.info("QA users fetched successfully.")
            return Response(response, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching QA users: %s", str(e))
            response = {
                "message": "Failed to fetch QA users.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# Vendor list view
class VendorListAPIView(APIView):
    
    def get(self, request, *args, **kwargs):
        logger.info("Fetching vendor users")
        try:
            # Filter users with the role 'Factory'
            vendor_users = User.objects.filter(role__role_name="Vendor")
            vendor_data = vendor_users.values("id", "name")

            response = {
                "message": "Vendor users fetched successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": list(vendor_data),
            }
            logger.info("Vendor users fetched successfully.")
            return Response(response, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching vendor users: %s", str(e))
            response = {
                "message": "Failed to fetch vendor users.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# Extension list view
class ExtensionListAPIView(APIView):
    def get(self, request, *args, **kwargs):
        logger.info("Fetching extension list")
        try:
            extensions = Extension.objects.all().distinct()
            serializer = ExtensionSerializer(extensions, many=True)

            response = {
                "message": "Extension fetched successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": serializer.data,
            }
            logger.info("Extension fetched successfully.")
            return Response(response, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching extension: %s", str(e))
            response = {
                "message": "Failed to fetch extension.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# Style details view
class StyleDetailsViewSet(viewsets.ModelViewSet):
    queryset = StyleDetails.objects.select_related("qa", "vendor").prefetch_related("task_style").all().order_by('-created_at')
    serializer_class = StyleDetailsSerializer
    
    # create style view
    def create(self, request, *args, **kwargs):
        data = request.data
        logger.info("Creating new StyleDetails entry.")

        try:
            with transaction.atomic():
                qa_user = User.objects.get(id=data["selectQA"])
                vendor_user = User.objects.get(id=data["selectVender"])

                style_details = StyleDetails.objects.create(
                    style_name=data["styleName"],
                    qa=qa_user,
                    vendor=vendor_user,
                    creator=request.user,
                    order_place_date=data["OTD"],
                    ship_date=data.get("shipDate"),
                    quantity=data["quantity"],
                    average_production_per_day=data["PPD"],
                    stitching=data["stitching"],
                    machine_required=data["Merchants"],
                    po_details=", ".join(data.get("selectPO", [])),
                )

                # Batch insert tasks
                task_objects = [
                    TaskDetails(
                        type_of_work=row.get("typeOfWork", "Unknown"),
                        style=style_details,
                        name=row.get("description"),
                        index=row.get("index"),
                        required_material=row.get("requiredMaterial"),
                        original_start_date=row.get("originalStartDate"),
                        required_days=int(row.get("requiredDays", 0)),
                        original_end_date=row.get("originalEndDate"),
                        end_date=row.get('final_Date', None)
                    )
                    for row in data.get("rows", [])
                ]
                created_tasks = TaskDetails.objects.bulk_create(task_objects)

                # Create task mapping for relationships
                task_mapping = {task.index: task for task in created_tasks}

                # Batch insert relationships
                relationship_objects = [
                    Relationship(
                        parent=task_mapping.get(relationship.get("parentIndex")),
                        child=task_mapping.get(relationship.get("childIndex")),
                        offset_days=relationship.get("offset", 0),
                    )
                    for relationship in data.get("relationships", [])
                    if task_mapping.get(relationship.get("parentIndex")) and task_mapping.get(relationship.get("childIndex"))
                ]
                Relationship.objects.bulk_create(relationship_objects)

            send_custom_notification(instance=style_details, request=request, context="CREATE_TNA")
            serializer = self.get_serializer(style_details)

            logger.info("StyleDetails created successfully.")
            return Response({
                "message": "T&A added successfully.",
                "error": False,
                "code": status.HTTP_201_CREATED,
                "data": {"data": serializer.data}
            }, status=status.HTTP_201_CREATED)

        except Exception as e:
            logger.error(f"Error creating StyleDetails: {e}")
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        

    def update(self, request, *args, **kwargs):
        data = request.data
        style_id = kwargs.get("pk")
        logger.info(f"Updating StyleDetails with ID {style_id}.")

        try:
            with transaction.atomic():
                style_details = StyleDetails.objects.get(id=style_id)

                # Update style fields
                style_details.style_name = data.get("styleName", style_details.style_name)
                style_details.order_place_date = data.get("OTD", style_details.order_place_date)
                style_details.ship_date = data.get("shipDate", style_details.ship_date)
                style_details.quantity = data.get("quantity", style_details.quantity)
                style_details.average_production_per_day = data.get("PPD", style_details.average_production_per_day)
                style_details.stitching = data.get("stitching", style_details.stitching)
                style_details.machine_required = data.get("Merchants", style_details.machine_required)
                style_details.po_details = ", ".join(data.get("selectPO", [])) or style_details.po_details
                style_details.save()

                # Fetch existing tasks
                existing_tasks = {task.id: task for task in TaskDetails.objects.filter(style=style_details)}
                new_tasks, updated_tasks = [], []

                # Process tasks (update or create)
                for row in data.get("rows", []):
                    task_id = row.get("id")
                    if task_id and task_id in existing_tasks:
                        task = existing_tasks[task_id]
                        task.type_of_work = row.get("typeOfWork", task.type_of_work)
                        task.name = row.get("description", task.name)
                        task.required_material = row.get("requiredMaterial", task.required_material)
                        task.original_start_date = row.get("originalStartDate", task.original_start_date)
                        task.required_days = int(row.get("requiredDays", task.required_days))
                        task.original_end_date = row.get("originalEndDate", task.original_end_date)
                        task.end_date = row.get('final_Date', task.end_date)
                        updated_tasks.append(task)
                    else:
                        new_tasks.append(
                            TaskDetails(
                                type_of_work=row.get("typeOfWork", "Unknown"),
                                style=style_details,
                                name=row.get("description"),
                                index=row.get("index"),
                                required_material=row.get("requiredMaterial"),
                                original_start_date=row.get("originalStartDate"),
                                required_days=int(row.get("requiredDays", 0)),
                                original_end_date=row.get("originalEndDate"),
                                end_date=row.get('final_Date', None)
                            )
                        )

                if updated_tasks:
                    TaskDetails.objects.bulk_update(updated_tasks, ["type_of_work", "name", "required_material",
                                                                    "original_start_date", "required_days",
                                                                    "original_end_date", "end_date"])
                if new_tasks:
                    TaskDetails.objects.bulk_create(new_tasks)

                # Refresh tasks after insertions
                all_tasks = {task.index: task for task in TaskDetails.objects.filter(style=style_details)}

                # Handle relationships: Delete old ones and insert updated
                Relationship.objects.filter(parent__style=style_details).delete()

                new_relationships = [
                    Relationship(
                        parent=all_tasks.get(relationship.get("parentIndex")),
                        child=all_tasks.get(relationship.get("childIndex")),
                        offset_days=relationship.get("offset", 0),
                    )
                    for relationship in data.get("relationships", [])
                    if all_tasks.get(relationship.get("parentIndex")) and all_tasks.get(relationship.get("childIndex"))
                ]
                if new_relationships:
                    Relationship.objects.bulk_create(new_relationships)

            send_custom_notification(instance=style_details, request=request, context="UPDATE_TNA")

            serializer = self.get_serializer(style_details)
            logger.info("StyleDetails updated successfully.")
            return Response({
                "message": "T&A updated successfully.",
                "error": False,
                "code": status.HTTP_200_OK,
                "data": {"data": serializer.data}
            }, status=status.HTTP_200_OK)

        except Exception as e:
            logger.error(f"Error updating StyleDetails: {e}")
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)    
        
    

# TNA soft delete
class DeleteStyleDetailsViewSet(APIView):
    def patch(self, request, pk):
        logger = logging.getLogger(__name__)

        style_detail = StyleDetails.objects.filter(id=pk).first()

        if not style_detail:
            logger.error(f"StyleDetails with ID {pk} not found.")
            return Response({
                "message": "StyleDetails not found.",
                "error": True,
                "status": status.HTTP_404_NOT_FOUND,
                "data": None,
            }, status=status.HTTP_404_NOT_FOUND)

        is_active = request.data.get("is_active", False)
        previous_is_active = style_detail.is_active
        style_detail.is_active = is_active
        style_detail.save()

        if is_active and not previous_is_active:
            logger.info(f"StyleDetails with ID {pk} activated successfully.")
            return Response({
                "message": "StyleDetails activated successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": {"id": pk, "is_active": is_active},
            }, status=status.HTTP_200_OK)

        elif not is_active and previous_is_active:
            logger.info(f"StyleDetails with ID {pk} deactivated successfully.")
            return Response({
                "message": "StyleDetails deactivated successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": {"id": pk, "is_active": is_active},
            }, status=status.HTTP_200_OK)

        else:
            logger.info(f"No change in active status for StyleDetails with ID {pk}.")
            return Response({
                "message": "StyleDetails status remains unchanged.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": {"id": pk, "is_active": previous_is_active},
            }, status=status.HTTP_200_OK)


# Notification read functionality
class ReadNotificationViewSet(APIView):
    def patch(self, request, pk):
        logger = logging.getLogger(__name__)
        notification = Notification.objects.filter(id=pk).first()

        if not notification:
            logger.error(f"Notification with ID {pk} not found.")
            return Response({
                "message": "Notification not found.",
                "error": True,
                "status": status.HTTP_404_NOT_FOUND,
                "data": None,
            }, status=status.HTTP_404_NOT_FOUND)

        is_read = request.data.get("is_read", False)
        previous_is_read = notification.is_read
        notification.is_read = is_read
        notification.save()

        if is_read and not previous_is_read:
            logger.info(f"Notification with ID {pk} marked as read.")
            return Response({
                "message": "Notification marked as read successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": {"id": pk, "is_read": is_read},
            }, status=status.HTTP_200_OK)

        elif not is_read and previous_is_read:
            logger.info(f"Notification with ID {pk} marked as unread.")
            return Response({
                "message": "Notification marked as unread successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": {"id": pk, "is_read": is_read},
            }, status=status.HTTP_200_OK)

        else:
            logger.info(f"No change in read status for notification with ID {pk}.")
            return Response({
                "message": "Notification status remains unchanged.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": {"id": pk, "is_read": previous_is_read},
            }, status=status.HTTP_200_OK)

# type of work view
class TypeofWorkViewSet(APIView):
    def get(self, request, *args, **kwargs):
        logger.info("Fetching type of work")
        try:
            type_of_work = TypeOfWork.objects.values("type_of_work").distinct().order_by('-created_at')
            response = {
                "message": "Type of work fetched successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": list(type_of_work),
            }
            logger.info("Type of work fetched successfully.")
            return Response(response, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching type of work: %s", str(e))
            response = {
                "message": "Failed to fetch type of work.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# manager list view
class ManagerListAPIView(APIView):
    def get(self, request, *args, **kwargs):
        logger.info("Fetching manager users")
        try:
            # Filter users with the role 'Manager'
            manager_users = User.objects.filter(role__role_name="Merchant").order_by('-id')
            manager_data = manager_users.values("id", "name")

            response = {
                "message": "Manager users fetched successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": list(manager_data),
            }
            logger.info("Manager users fetched successfully.")
            return Response(response, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching manager users: %s", str(e))
            response = {
                "message": "Failed to fetch manager users.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# update user view
class UpdateUserAPIView(APIView):
    def patch(self, request, pk):
        logger = logging.getLogger(__name__)
        user = User.objects.filter(id=pk).first()
        if not user:
            logger.error(f"User with ID {pk} not found.")
            return Response({
                "message": "User not found.",
                "error": True,
                "status": status.HTTP_404_NOT_FOUND,
                "data": None,
            }, status=status.HTTP_404_NOT_FOUND)

        email = request.data.get("email")
        name = request.data.get("name")
        password = request.data.get("password")
        confirm_password = request.data.get("confirm_password")
        role_id = request.data.get("role")
        department = request.data.get("department")
        groups = request.data.get("groups", [])
        designation = request.data.get("designation")

        if password and confirm_password:
            if password != confirm_password:
                logger.error(f"Password and confirm_password do not match for User ID {pk}.")
                return Response({
                    "message": "Password and confirm_password do not match.",
                    "error": True,
                    "status": status.HTTP_400_BAD_REQUEST,
                    "data": None,
                }, status=status.HTTP_400_BAD_REQUEST)
            user.set_password(str(password))

        if email:
            user.email = email
        if name:
            user.name = name
        if department:
            user.department = department
        if designation:
            user.designation = designation

        if role_id:
            role = Role.objects.filter(id=role_id).first()
            if not role:
                logger.error(f"Role with ID {role_id} not found.")
                return Response({
                    "message": "Role not found.",
                    "error": True,
                    "status": status.HTTP_404_NOT_FOUND,
                    "data": None,
                }, status=status.HTTP_404_NOT_FOUND)
            user.role = role

        if groups:
            user.groups.set(groups)
        user.save()
        logger.info(f"User with ID {pk} updated successfully.")
        return Response({
            "message": "User updated successfully.",
            "error": False,
            "status": status.HTTP_200_OK,
            "data": {
                "id": pk,
                "email": user.email,
                "name": user.name,
                "role": user.role.id if user.role else None,
                "department": user.department,
                "designation": user.designation,
                "groups": [group.id for group in user.groups.all()],
            },
        }, status=status.HTTP_200_OK)


# Style display view
class StyleDisplayView(generics.ListAPIView):
    queryset = TaskDetails.objects.all().order_by('-created_at')
    serializer_class = StyleListSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_class = TaskDataFilter
    # permission_classes = [IsAuthenticated, CustomPermission]
    # view_name = "t&a_list_views"


# QA calendar view
class QAcalendarListAPIView(generics.ListAPIView):
    serializer_class = QACalendarSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_class = TaskDataFilter
    # permission_classes = [IsAuthenticated,CustomPermission]
    # view_name = "qa_calender_list"

    def get_queryset(self):
        type_of_work_filter = ["WEB/TOP", "FIT", "PP", "INITIAL", "MID", "DKC", "FINAL FABRIC DETAILS"]
        return TaskDetails.objects.filter(type_of_work__in=type_of_work_filter)

    def list(self, request, *args, **kwargs):
        try:
            queryset = self.get_queryset()
            queryset = self.filter_queryset(queryset)
            serializer = self.get_serializer(queryset, many=True)

            response_data = {
                "message": "QA calendar data fetched successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": serializer.data,
            }
            logger.info("QA calendar data fetched successfully.")
            return Response(response_data, status=status.HTTP_200_OK)

        except Exception as e:
            logger.error(f"Error fetching QA calendar data: {str(e)}")

            response_data = {
                "message": "Failed to fetch QA calendar data.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# user permission view
class UserPermissionViewSet(viewsets.ModelViewSet):
    queryset = UserPermission.objects.all()
    serializer_class = UserPermissionSerializer
    
    # Create user permission view
    def create(self, request, *args, **kwargs):
        logger.info(f"Create UserPermission request received: {request.data}")

        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            logger.info(f"UserPermission created successfully with ID: {serializer.data['id']}")
            response_data = {
                "message": "UserPermission created successfully",
                "error": False,
                "status": status.HTTP_201_CREATED,
                "data": serializer.data,
            }
            return Response(response_data, status=status.HTTP_201_CREATED)
        else:
            logger.error("Create UserPermission failed: {serializer.errors}")
            response_data = {
                "message": f"Create UserPermission failed",
                "error": True,
                "status": status.HTTP_400_BAD_REQUEST,
                "data": serializer.errors,
            }
            return Response(response_data, status=status.HTTP_400_BAD_REQUEST)
        
    # Update user permission view
    def update(self, request, *args, **kwargs):
        user_permission = self.get_object()
        logger.info(f"Update UserPermission request received for ID {user_permission.id}: {request.data}")

        serializer = self.get_serializer(user_permission, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            logger.info(f"UserPermission ID {user_permission.id} updated successfully")
            response_data = {
                "message": f"Update UserPermission request received for ID {user_permission.id}: {request.data}",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": serializer.data,
            }
            return Response(response_data, status=status.HTTP_200_OK)
        else:
            logger.error(f"Update UserPermission failed for ID {user_permission.id}: {serializer.errors}")
            response_data = {
                "message": "Update UserPermission failed",
                "error": True,
                "status": status.HTTP_400_BAD_REQUEST,
                "data": serializer.errors,
            }
            return Response(response_data, status=status.HTTP_400_BAD_REQUEST)

    # Delete user permission view
    def destroy(self, request, *args, **kwargs):
        user_permission = self.get_object()
        logger.info(f"Delete UserPermission request received for ID {user_permission.id}")

        user_permission.delete()
        logger.info(f"UserPermission ID {user_permission.id} deleted successfully")
        response_data = {
            "message": f"UserPermission ID {user_permission.id} deleted successfully",
            "error": False,
            "status": status.HTTP_204_NO_CONTENT,
            "data": 'NO Content',
        }
        return Response(response_data, status=status.HTTP_204_NO_CONTENT)
    
    # List user permission view
    def list(self, request, *args, **kwargs):
        logger.info("List UserPermission request received")

        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        logger.info(f"Listed {len(queryset)} UserPermission entries successfully")
        response_data = {
            "message": f"Listed {len(queryset)} UserPermission entries successfully",
            "error": False,
            "status": status.HTTP_200_OK,
            "data": serializer.data,
        }
        return Response(response_data, status=status.HTTP_200_OK)

# userlist view
class UserListView(APIView):
    def get(self, request, *args, **kwargs):
        logger.info("Fetching user list")
        try:
            users = User.objects.all()
            serializer = UserSerializer(users, many=True)

            response = {
                "message": "User list fetched successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": serializer.data,
            }
            logger.info("User list fetched successfully.")
            return Response(response, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error("Error fetching user list: %s", str(e))
            response = {
                "message": "Failed to fetch user list.",
                "error": True,
                "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                "data": None,
            }
            return Response(response, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        

# user profile view
class UserProfileView(generics.RetrieveUpdateAPIView):
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user

# Form68 view
class CreateForm68APIView(APIView):

    def post(self, request, *args, **kwargs):
        logger.info("Creating a new Form68 instance")
        ext_id = request.data.get('extension')

        try:
            # Retrieve the Extension instance based on the provided ext_id
            extension_instance = Extension.objects.get(id=ext_id)
        except Extension.DoesNotExist:
            logger.error("Extension with id %s does not exist.", ext_id)
            return Response(
                {"error": "Invalid extension ID.", "details": f"Extension with id {ext_id} does not exist."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        serializer = Form68Serializers(data=request.data)
        if serializer.is_valid():
            serializer.save(extension=extension_instance)
            send_custom_notification(
                instance=serializer.instance,
                request=request,
                context="FORM68",
            )
            logger.info("Form68 instance created successfully: %s", serializer.instance.form_id)
            response = {
                "message": "Form68 instance created successfully.",
                "error": False,
                "status": status.HTTP_201_CREATED,
                "data": serializer.data,
            }
            return Response(response, status=status.HTTP_201_CREATED)
        else:
            logger.error("Validation failed for Form68 data: %s", serializer.errors)
            return Response(
                {"error": "Validation failed.", "details": serializer.errors},
                status=status.HTTP_400_BAD_REQUEST,
            )

# list form68 view
class ListForm68APIView(generics.ListAPIView):
    queryset = Form68Model.objects.all()
    serializer_class = Form68Serializers
    pagination_class = PageNumberPagination

    def list(self, request, *args, **kwargs):
        logger.info("Fetching Form68 data")
        try:
            response = super().list(request, *args, **kwargs)
            response.data = {
                "message": "Form68 data fetched successfully.",
                "error": False,
                "status": status.HTTP_200_OK,
                "data": response.data,
            }
            logger.info("Form68 data fetched and paginated successfully")
            return response
        except Exception as e:
            logger.error("Error fetching Form68 data: %s", str(e))
            return Response(
                {
                    "message": "Failed to fetch Form68 data.",
                    "error": True,
                    "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                    "data": None,
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

# dashboard view
class DashboardAPIView(generics.ListAPIView):
    
    def get(self, request):
        try:
            total_notifications = Notification.objects.count()
            total_style_details = StyleDetails.objects.count()
            total_form68 = Form68Model.objects.count()

            top_styles_with_max_extensions = (
                StyleDetails.objects
                .annotate(extension_count=Count('task_style__extension_task'))
                .order_by('-extension_count')[:5]
                .values('id', 'style_name', 'extension_count')
            )
            top_styles_count_with_max_extension = len(top_styles_with_max_extensions)
            admin_unapproved_extensions_count = Extension.objects.filter(
                approved_status=False, extension_days__gte=3
            ).count()

            today = timezone.now().date()
            fourteen_days_later = today + timedelta(days=14)
            styles_with_tasks_ending_in_14_days = StyleDetails.objects.filter(
                task_style__end_date__range=(today, fourteen_days_later)
            ).count()

            data = {
                "total_notifications": total_notifications,
                "total_tna_details": total_style_details,
                "total_form68": total_form68,
                "top_styles_with_max_extensions": list(top_styles_with_max_extensions),
                "top_tna_behalf_of_ext": top_styles_count_with_max_extension,
                "admin_pending_approval": admin_unapproved_extensions_count,
                "tna_ending_in_14_days": styles_with_tasks_ending_in_14_days,
            }
            logger.info("Dashboard data fetched successfully", extra={"data": data})
            return Response({"message": "Data fetched successfully", "status": status.HTTP_200_OK, "error": False, "data": data}, status=status.HTTP_200_OK)
        
        except Exception as e:
            logger.error("Error fetching dashboard data", exc_info=True)
            return Response({"message": "Failed to fetch dashboard data", "status": status.HTTP_500_INTERNAL_SERVER_ERROR, "error": str(e), "data": None}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
# getform68 view    
class GetForm68APIView(generics.RetrieveAPIView):
    serializer_class = Form68Serializers

    def get_queryset(self):
        pk = self.kwargs.get("id")
        if not pk:
            return Form68Model.objects.none()
        return Form68Model.objects.filter(form_id=pk)

    def retrieve(self, request, *args, **kwargs):
        logger.info("Fetching Form68 data using serializer")
        try:
            queryset = self.get_queryset().first()  # Get single object
            if queryset:
                serializer = self.get_serializer(queryset)
                response_data = {
                    "message": "Form68 data fetched successfully.",
                    "error": False,
                    "status": status.HTTP_200_OK,
                    "data": serializer.data,
                }
                logger.info("Form68 data fetched successfully")
                return Response(response_data, status=status.HTTP_200_OK)
            else:
                return Response(
                    {
                        "message": "No Form68 data found.",
                        "error": False,
                        "status": status.HTTP_204_NO_CONTENT,
                        "data": None,
                    },
                    status=status.HTTP_204_NO_CONTENT,
                )
        except Exception as e:
            logger.error(f"Error fetching Form68 data: {str(e)}")
            return Response(
                {
                    "message": "Failed to fetch Form68 data.",
                    "error": True,
                    "status": status.HTTP_500_INTERNAL_SERVER_ERROR,
                    "data": None,
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from .models import StyleDetails, TaskDetails, Relationship, Extension
from simple_history.utils import update_change_reason


class HistoryAPIView(APIView):
    """
    API to fetch history of all related models (StyleDetails, TaskDetails, Relationship, Extension).
    Only returns records where changes have occurred.
    Excludes duplicates and shows dynamic history_id.
    """

    def get(self, request, style_id):
        history_data = []

        # Function to process history from any model
        def process_history(history_queryset, model_name):
            processed_ids = set()  # To remove duplicates
            history_list = []

            for history_instance in history_queryset:
                if history_instance.prev_record:
                    delta = history_instance.diff_against(history_instance.prev_record)
                    if delta.changed_fields and history_instance.history_id not in processed_ids:
                        processed_ids.add(history_instance.history_id)
                        history_list.append({
                            'history_id': history_instance.history_id,
                            'model': model_name,
                            'changed_by': history_instance.history_user.username if history_instance.history_user else None,
                            'history_type': history_instance.get_history_type_display(),
                            'history_date': history_instance.history_date,
                            'changes': [
                                {
                                    'field': change.field,
                                    'old_value': change.old,
                                    'new_value': change.new
                                } for change in delta.changes
                            ]
                        })
            return history_list

        # Process each related model
        style_history = process_history(StyleDetails.history.filter(id=style_id), "StyleDetails")
        task_history = process_history(TaskDetails.history.filter(style_id=style_id), "TaskDetails")
        relationship_history = process_history(
            Relationship.history.filter(
                parent__style_id=style_id
            ) | Relationship.history.filter(
                child__style_id=style_id
            ), 
            "Relationship"
        )
        extension_history = process_history(
            Extension.history.filter(sub_task__style_id=style_id), "Extension"
        )

        # Combine all histories
        history_data.extend(style_history)
        history_data.extend(task_history)
        history_data.extend(relationship_history)
        history_data.extend(extension_history)

        # Sort by history_date (latest first)
        history_data.sort(key=lambda x: x['history_date'], reverse=True)

        return Response({
            "message": "History fetched successfully",
            "error": False,
            "status": status.HTTP_200_OK,
            "total_records": len(history_data),
            "data": history_data
            
        }, status=status.HTTP_200_OK)



class ExtensionApproveDetailsView(APIView):
    """
    API to get all TaskDetails and related Extensions for a given style_id,
    showing the complete parent-child relationship hierarchy from the Relationship model.
    - Only related parent-child tasks get color codes based on hierarchy.
    - Unrelated tasks appear without a color.
    - Shows if child's date changed due to a parent's date change.
    """

    def get(self, request, tna_id):
        logger.info(f"API request received: GET /task-extension-color/{tna_id}/")
        try:
            # Fetch all tasks with extensions and relationships
            tasks = TaskDetails.objects.filter(style_id=tna_id).prefetch_related(
                Prefetch('extension_task', queryset=Extension.objects.all()),
                'task_parents', 'task_child'
            )
            task_map = {task.id: task for task in tasks}
            logger.info(f"Retrieved {tasks.count()} tasks for style_id: {tna_id}")

            # Fetch relationships for the given style_id
            relationships = Relationship.objects.filter(parent__style_id=tna_id)
            logger.info(f"Retrieved {relationships.count()} relationships for style_id: {tna_id}")

            # Identify changed parent tasks (end_date changed)
            changed_parents = set(
                task.id for task in tasks
                if task.end_date and task.original_end_date and task.end_date != task.original_end_date
            )
            logger.info(f"Identified {len(changed_parents)} changed parent tasks.")

            # Build parent-child map
            parent_child_map = {}
            for rel in relationships:
                parent_child_map.setdefault(rel.parent.id, []).append(rel.child.id)

            visited = set()

            parent_color = "rgba(173, 216, 230, 0.4)"  # Light Blue
            child_color = "rgba(144, 238, 144, 0.4)"   # Light Green

            def build_relationship_hierarchy(task_id, level, parent_changed=False, is_parent=True):
                """
                Recursively build parent-child structure:
                - Parent tasks get the parent color.
                - Child tasks get the child color.
                - Mark if child's date changed due to parent's change.
                """
                if task_id in visited:
                    return []
                visited.add(task_id)

                task = task_map.get(task_id)
                has_relationship = (
                    task_id in parent_child_map or
                    any(task_id in children for children in parent_child_map.values())
                )

                # Check if child's date changed due to parent
                date_changed_due_to_parent = parent_changed and (
                    task.end_date != task.original_end_date
                )

                task_data = {
                    "task": ExtTaskDetailsSerializer(task).data,
                    "color_code": parent_color if is_parent else child_color if has_relationship else None,
                    "level": level if has_relationship else None,
                    "parent_date_changed": date_changed_due_to_parent
                }

                # Recursively process children
                children = []
                for child_id in parent_child_map.get(task_id, []):
                    child_parent_changed = task_id in changed_parents
                    children.extend(build_relationship_hierarchy(child_id, level + 1, child_parent_changed, is_parent=False))

                return [task_data] + children

            # Prepare final response data
            response_data = []
            related_task_ids = set(parent_child_map.keys()).union(*parent_child_map.values())

            for task in tasks:
                if task.id not in visited:
                    if task.id in related_task_ids:
                        # Related tasks with hierarchy and color
                        response_data.extend(build_relationship_hierarchy(task.id, 0))
                    else:
                        # Unrelated tasks without color
                        response_data.append({
                            "task": ExtTaskDetailsSerializer(task).data,
                            "color_code": None,
                            "level": None,
                            "parent_date_changed": False
                        })

            logger.info(f"Response prepared with {len(response_data)} tasks.")
            return Response({"status": True, "data": response_data}, status=status.HTTP_200_OK)

        except Exception as e:
            logger.error(f"Error in ExtensionApproveDetailsView for style_id {tna_id}: {str(e)}")
            return Response({"status": False, "error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

